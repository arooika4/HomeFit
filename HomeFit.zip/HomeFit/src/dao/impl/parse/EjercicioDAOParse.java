package dao.impl.parse;

import dao.EjercicioDAO;
import model.Ejercicio;
import service.Back4AppConnection;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class EjercicioDAOParse implements EjercicioDAO {

    private static final String CLASE = "Ejercicio";

    // ── CREATE ────────────────────────────────────────────────────────────────
    @Override
    public void crear(Ejercicio ejercicio) {
        try {
            HttpURLConnection conn = Back4AppConnection.conectar(CLASE, "POST");

            String json = "{\"id_ejercicio\":" + ejercicio.getIdEjercicio()
                        + ",\"nombre\":\"" + ejercicio.getNombre() + "\""
                        + ",\"descripcion\":\"" + ejercicio.getDescripcion() + "\""
                        + ",\"referencia\":\"" + ejercicio.getVideoReferencia() + "\""
                        + ",\"id_rutina\":" + ejercicio.getIdRutina() + "}";

            try (OutputStream os = conn.getOutputStream()) {
                os.write(json.getBytes("UTF-8"));
            }

            int status = conn.getResponseCode();
            if (status == 201) {
                System.out.println("[OK] Ejercicio creado: " + ejercicio.getNombre());
            } else {
                System.out.println("[ERROR " + status + "] crear Ejercicio: " + leerRespuesta(conn));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ── READ (por id_ejercicio) ───────────────────────────────────────────────
    @Override
    public Ejercicio obtener(int id) {
        try {
            HttpURLConnection conn = Back4AppConnection.conectar(
                CLASE + "?where={\"id_ejercicio\":" + id + "}", "GET");

            int status = conn.getResponseCode();
            String respuesta = leerRespuesta(conn);

            if (status == 200) {
                return parsearPrimero(respuesta);
            } else {
                System.out.println("[ERROR " + status + "] obtener Ejercicio: " + respuesta);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    // ── READ ALL ──────────────────────────────────────────────────────────────
    @Override
    public List<Ejercicio> obtenerTodos() {
        List<Ejercicio> lista = new ArrayList<>();
        try {
            HttpURLConnection conn = Back4AppConnection.conectar(CLASE, "GET");

            int status = conn.getResponseCode();
            String respuesta = leerRespuesta(conn);

            if (status == 200) {
                lista = parsearLista(respuesta);
            } else {
                System.out.println("[ERROR " + status + "] obtenerTodos Ejercicio: " + respuesta);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return lista;
    }

    // ── UPDATE ────────────────────────────────────────────────────────────────
    @Override
    public void actualizar(Ejercicio ejercicio) {
        try {
            String objectId = obtenerObjectId(ejercicio.getIdEjercicio());
            if (objectId == null) { System.out.println("[ERROR] Ejercicio no encontrado para actualizar"); return; }

            HttpURLConnection conn = Back4AppConnection.conectar(CLASE + "/" + objectId, "PUT");

            String json = "{\"nombre\":\"" + ejercicio.getNombre() + "\""
                        + ",\"descripcion\":\"" + ejercicio.getDescripcion() + "\""
                        + ",\"referencia\":\"" + ejercicio.getVideoReferencia() + "\""
                        + ",\"id_rutina\":" + ejercicio.getIdRutina() + "}";

            try (OutputStream os = conn.getOutputStream()) {
                os.write(json.getBytes("UTF-8"));
            }

            int status = conn.getResponseCode();
            if (status == 200) {
                System.out.println("[OK] Ejercicio actualizado: " + ejercicio.getNombre());
            } else {
                System.out.println("[ERROR " + status + "] actualizar Ejercicio: " + leerRespuesta(conn));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ── DELETE ────────────────────────────────────────────────────────────────
    @Override
    public void eliminar(int id) {
        try {
            String objectId = obtenerObjectId(id);
            if (objectId == null) { System.out.println("[ERROR] Ejercicio no encontrado para eliminar"); return; }

            HttpURLConnection conn = Back4AppConnection.conectar(CLASE + "/" + objectId, "DELETE");

            int status = conn.getResponseCode();
            if (status == 200) {
                System.out.println("[OK] Ejercicio eliminado id: " + id);
            } else {
                System.out.println("[ERROR " + status + "] eliminar Ejercicio: " + leerRespuesta(conn));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ── UTILIDADES ────────────────────────────────────────────────────────────

    private String obtenerObjectId(int idEjercicio) throws Exception {
        HttpURLConnection conn = Back4AppConnection.conectar(
            CLASE + "?where={\"id_ejercicio\":" + idEjercicio + "}&limit=1", "GET");
        String respuesta = leerRespuesta(conn);
        return extraerValor(respuesta, "objectId");
    }

    private Ejercicio parsearPrimero(String json) {
        if (!json.contains("\"id_ejercicio\"")) return null;
        Ejercicio e = new Ejercicio();
        String idStr = extraerValor(json, "id_ejercicio");
        if (idStr != null) e.setIdEjercicio(Integer.parseInt(idStr));
        e.setNombre(extraerValor(json, "nombre"));
        e.setDescripcion(extraerValor(json, "descripcion"));
        e.setVideoReferencia(extraerValor(json, "referencia"));
        String idRutinaStr = extraerValor(json, "id_rutina");
        if (idRutinaStr != null) e.setIdRutina(Integer.parseInt(idRutinaStr));
        return e;
    }

    private List<Ejercicio> parsearLista(String json) {
        List<Ejercicio> lista = new ArrayList<>();
        String[] objetos = json.split("\\{");
        for (String obj : objetos) {
            if (obj.contains("\"id_ejercicio\"")) {
                lista.add(parsearPrimero("{" + obj));
            }
        }
        return lista;
    }

    private String leerRespuesta(HttpURLConnection conn) throws Exception {
        InputStream is;
        try { is = conn.getInputStream(); } catch (Exception e) { is = conn.getErrorStream(); }
        if (is == null) return "";
        Scanner sc = new Scanner(is, "UTF-8");
        StringBuilder sb = new StringBuilder();
        while (sc.hasNextLine()) sb.append(sc.nextLine());
        sc.close();
        return sb.toString();
    }

    private String extraerValor(String json, String clave) {
        String buscar = "\"" + clave + "\":\"";
        int inicio = json.indexOf(buscar);
        if (inicio != -1) {
            inicio += buscar.length();
            int fin = json.indexOf("\"", inicio);
            if (fin != -1) return json.substring(inicio, fin);
        }
        buscar = "\"" + clave + "\":";
        inicio = json.indexOf(buscar);
        if (inicio != -1) {
            inicio += buscar.length();
            int fin = json.indexOf(",", inicio);
            if (fin == -1) fin = json.indexOf("}", inicio);
            if (fin != -1) return json.substring(inicio, fin).trim();
        }
        return null;
    }
}

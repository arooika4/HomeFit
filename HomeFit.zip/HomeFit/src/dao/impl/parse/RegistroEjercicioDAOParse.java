package dao.impl.parse;

import dao.RegistroEjercicioDAO;
import model.RegistroEjercicio;
import service.Back4AppConnection;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class RegistroEjercicioDAOParse implements RegistroEjercicioDAO {

    private static final String CLASE = "RegistroEjercicio";

    // ── CREATE ────────────────────────────────────────────────────────────────
    @Override
    public void crear(RegistroEjercicio registro) {
        try {
            HttpURLConnection conn = Back4AppConnection.conectar(CLASE, "POST");

            String json = "{\"id_registro\":" + registro.getIdRegistro()
                        + ",\"tiempo\":" + registro.getTiempo()
                        + ",\"nivel\":\"" + registro.getNivel() + "\""
                        + ",\"referencia\":\"" + registro.getFoto() + "\""
                        + ",\"id_sesion\":" + registro.getIdSesion()
                        + ",\"id_ejercicio\":" + registro.getIdEjercicio() + "}";

            try (OutputStream os = conn.getOutputStream()) {
                os.write(json.getBytes("UTF-8"));
            }

            int status = conn.getResponseCode();
            if (status == 201) {
                System.out.println("[OK] RegistroEjercicio creado id: " + registro.getIdRegistro());
            } else {
                System.out.println("[ERROR " + status + "] crear RegistroEjercicio: " + leerRespuesta(conn));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ── READ (por id_registro) ────────────────────────────────────────────────
    @Override
    public RegistroEjercicio obtener(int id) {
        try {
            HttpURLConnection conn = Back4AppConnection.conectar(
                CLASE + "?where={\"id_registro\":" + id + "}", "GET");

            int status = conn.getResponseCode();
            String respuesta = leerRespuesta(conn);

            if (status == 200) {
                return parsearPrimero(respuesta);
            } else {
                System.out.println("[ERROR " + status + "] obtener RegistroEjercicio: " + respuesta);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    // ── READ ALL ──────────────────────────────────────────────────────────────
    @Override
    public List<RegistroEjercicio> obtenerTodos() {
        List<RegistroEjercicio> lista = new ArrayList<>();
        try {
            HttpURLConnection conn = Back4AppConnection.conectar(CLASE, "GET");

            int status = conn.getResponseCode();
            String respuesta = leerRespuesta(conn);

            if (status == 200) {
                lista = parsearLista(respuesta);
            } else {
                System.out.println("[ERROR " + status + "] obtenerTodos RegistroEjercicio: " + respuesta);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return lista;
    }

    // ── UPDATE ────────────────────────────────────────────────────────────────
    @Override
    public void actualizar(RegistroEjercicio registro) {
        try {
            String objectId = obtenerObjectId(registro.getIdRegistro());
            if (objectId == null) { System.out.println("[ERROR] RegistroEjercicio no encontrado para actualizar"); return; }

            HttpURLConnection conn = Back4AppConnection.conectar(CLASE + "/" + objectId, "PUT");

            String json = "{\"tiempo\":" + registro.getTiempo()
                        + ",\"nivel\":\"" + registro.getNivel() + "\""
                        + ",\"referencia\":\"" + registro.getFoto() + "\""
                        + ",\"id_sesion\":" + registro.getIdSesion()
                        + ",\"id_ejercicio\":" + registro.getIdEjercicio() + "}";

            try (OutputStream os = conn.getOutputStream()) {
                os.write(json.getBytes("UTF-8"));
            }

            int status = conn.getResponseCode();
            if (status == 200) {
                System.out.println("[OK] RegistroEjercicio actualizado id: " + registro.getIdRegistro());
            } else {
                System.out.println("[ERROR " + status + "] actualizar RegistroEjercicio: " + leerRespuesta(conn));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ── DELETE ────────────────────────────────────────────────────────────────
    @Override
    public void eliminar(int id) {
        try {
            String objectId = obtenerObjectId(id);
            if (objectId == null) { System.out.println("[ERROR] RegistroEjercicio no encontrado para eliminar"); return; }

            HttpURLConnection conn = Back4AppConnection.conectar(CLASE + "/" + objectId, "DELETE");

            int status = conn.getResponseCode();
            if (status == 200) {
                System.out.println("[OK] RegistroEjercicio eliminado id: " + id);
            } else {
                System.out.println("[ERROR " + status + "] eliminar RegistroEjercicio: " + leerRespuesta(conn));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ── UTILIDADES ────────────────────────────────────────────────────────────

    private String obtenerObjectId(int idRegistro) throws Exception {
        HttpURLConnection conn = Back4AppConnection.conectar(
            CLASE + "?where={\"id_registro\":" + idRegistro + "}&limit=1", "GET");
        String respuesta = leerRespuesta(conn);
        return extraerValor(respuesta, "objectId");
    }

    private RegistroEjercicio parsearPrimero(String json) {
        if (!json.contains("\"id_registro\"")) return null;
        RegistroEjercicio r = new RegistroEjercicio();
        String idStr = extraerValor(json, "id_registro");
        if (idStr != null) r.setIdRegistro(Integer.parseInt(idStr));
        String tiempoStr = extraerValor(json, "tiempo");
        if (tiempoStr != null) r.setTiempo(Integer.parseInt(tiempoStr));
        r.setNivel(extraerValor(json, "nivel"));
        r.setFoto(extraerValor(json, "referencia"));
        String idSesionStr = extraerValor(json, "id_sesion");
        if (idSesionStr != null) r.setIdSesion(Integer.parseInt(idSesionStr));
        String idEjercicioStr = extraerValor(json, "id_ejercicio");
        if (idEjercicioStr != null) r.setIdEjercicio(Integer.parseInt(idEjercicioStr));
        return r;
    }

    private List<RegistroEjercicio> parsearLista(String json) {
        List<RegistroEjercicio> lista = new ArrayList<>();
        String[] objetos = json.split("\\{");
        for (String obj : objetos) {
            if (obj.contains("\"id_registro\"")) {
                RegistroEjercicio r = parsearPrimero("{" + obj);
                if (r != null) lista.add(r);
            }
        }
        return lista;
    }

    private String leerRespuesta(HttpURLConnection conn) throws Exception {
        InputStream is;
        try { is = conn.getInputStream(); } catch (Exception e) { is = conn.getErrorStream(); }
        if (is == null) return "";
        Scanner sc = new Scanner(is, "UTF-8");
        StringBuilder sb = new StringBuilder();
        while (sc.hasNextLine()) sb.append(sc.nextLine());
        sc.close();
        return sb.toString();
    }

    private String extraerValor(String json, String clave) {
        String buscar = "\"" + clave + "\":\"";
        int inicio = json.indexOf(buscar);
        if (inicio != -1) {
            inicio += buscar.length();
            int fin = json.indexOf("\"", inicio);
            if (fin != -1) return json.substring(inicio, fin);
        }
        buscar = "\"" + clave + "\":";
        inicio = json.indexOf(buscar);
        if (inicio != -1) {
            inicio += buscar.length();
            int fin = json.indexOf(",", inicio);
            if (fin == -1) fin = json.indexOf("}", inicio);
            if (fin != -1) return json.substring(inicio, fin).trim();
        }
        return null;
    }
}

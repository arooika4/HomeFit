package dao.impl.parse;

import dao.RutinaDAO;
import model.Rutina;
import service.Back4AppConnection;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class RutinaDAOParse implements RutinaDAO {

    private static final String CLASE = "Rutina";

    // ── CREATE ────────────────────────────────────────────────────────────────
    @Override
    public void crear(Rutina rutina) {
        try {
            HttpURLConnection conn = Back4AppConnection.conectar(CLASE, "POST");

            String json = "{\"id_rutina\":" + rutina.getIdRutina()
                        + ",\"nombre\":\"" + rutina.getNombre() + "\"}";

            try (OutputStream os = conn.getOutputStream()) {
                os.write(json.getBytes("UTF-8"));
            }

            int status = conn.getResponseCode();
            if (status == 201) {
                System.out.println("[OK] Rutina creada: " + rutina.getNombre());
            } else {
                System.out.println("[ERROR " + status + "] crear Rutina: " + leerRespuesta(conn));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ── READ (por id_rutina) ──────────────────────────────────────────────────
    @Override
    public Rutina obtener(int id) {
        try {
            HttpURLConnection conn = Back4AppConnection.conectar(
                CLASE + "?where={\"id_rutina\":" + id + "}", "GET");

            int status = conn.getResponseCode();
            String respuesta = leerRespuesta(conn);

            if (status == 200) {
                return parsearPrimera(respuesta);
            } else {
                System.out.println("[ERROR " + status + "] obtener Rutina: " + respuesta);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    // ── READ ALL ──────────────────────────────────────────────────────────────
    @Override
    public List<Rutina> obtenerTodas() {
        List<Rutina> lista = new ArrayList<>();
        try {
            HttpURLConnection conn = Back4AppConnection.conectar(CLASE, "GET");

            int status = conn.getResponseCode();
            String respuesta = leerRespuesta(conn);

            if (status == 200) {
                lista = parsearLista(respuesta);
            } else {
                System.out.println("[ERROR " + status + "] obtenerTodas Rutina: " + respuesta);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return lista;
    }

    // ── UPDATE ────────────────────────────────────────────────────────────────
    @Override
    public void actualizar(Rutina rutina) {
        try {
            String objectId = obtenerObjectId(rutina.getIdRutina());
            if (objectId == null) { System.out.println("[ERROR] Rutina no encontrada para actualizar"); return; }

            HttpURLConnection conn = Back4AppConnection.conectar(CLASE + "/" + objectId, "PUT");

            String json = "{\"nombre\":\"" + rutina.getNombre() + "\"}";
            try (OutputStream os = conn.getOutputStream()) {
                os.write(json.getBytes("UTF-8"));
            }

            int status = conn.getResponseCode();
            if (status == 200) {
                System.out.println("[OK] Rutina actualizada: " + rutina.getNombre());
            } else {
                System.out.println("[ERROR " + status + "] actualizar Rutina: " + leerRespuesta(conn));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ── DELETE ────────────────────────────────────────────────────────────────
    @Override
    public void eliminar(int id) {
        try {
            String objectId = obtenerObjectId(id);
            if (objectId == null) { System.out.println("[ERROR] Rutina no encontrada para eliminar"); return; }

            HttpURLConnection conn = Back4AppConnection.conectar(CLASE + "/" + objectId, "DELETE");

            int status = conn.getResponseCode();
            if (status == 200) {
                System.out.println("[OK] Rutina eliminada id: " + id);
            } else {
                System.out.println("[ERROR " + status + "] eliminar Rutina: " + leerRespuesta(conn));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ── UTILIDADES ────────────────────────────────────────────────────────────

    private String obtenerObjectId(int idRutina) throws Exception {
        HttpURLConnection conn = Back4AppConnection.conectar(
            CLASE + "?where={\"id_rutina\":" + idRutina + "}&limit=1", "GET");
        String respuesta = leerRespuesta(conn);
        return extraerValor(respuesta, "objectId");
    }

    private Rutina parsearPrimera(String json) {
        if (!json.contains("\"id_rutina\"")) return null;
        Rutina r = new Rutina();
        String idStr = extraerValor(json, "id_rutina");
        if (idStr != null) r.setIdRutina(Integer.parseInt(idStr));
        r.setNombre(extraerValor(json, "nombre"));
        return r;
    }

    private List<Rutina> parsearLista(String json) {
        List<Rutina> lista = new ArrayList<>();
        String[] objetos = json.split("\\{");
        for (String obj : objetos) {
            if (obj.contains("\"id_rutina\"")) {
                Rutina r = new Rutina();
                String idStr = extraerValor("{" + obj, "id_rutina");
                if (idStr != null) r.setIdRutina(Integer.parseInt(idStr));
                r.setNombre(extraerValor("{" + obj, "nombre"));
                lista.add(r);
            }
        }
        return lista;
    }

    private String leerRespuesta(HttpURLConnection conn) throws Exception {
        InputStream is;
        try { is = conn.getInputStream(); } catch (Exception e) { is = conn.getErrorStream(); }
        if (is == null) return "";
        Scanner sc = new Scanner(is, "UTF-8");
        StringBuilder sb = new StringBuilder();
        while (sc.hasNextLine()) sb.append(sc.nextLine());
        sc.close();
        return sb.toString();
    }

    private String extraerValor(String json, String clave) {
        // Intenta primero como String
        String buscar = "\"" + clave + "\":\"";
        int inicio = json.indexOf(buscar);
        if (inicio != -1) {
            inicio += buscar.length();
            int fin = json.indexOf("\"", inicio);
            if (fin != -1) return json.substring(inicio, fin);
        }
        // Intenta como número
        buscar = "\"" + clave + "\":";
        inicio = json.indexOf(buscar);
        if (inicio != -1) {
            inicio += buscar.length();
            int fin = json.indexOf(",", inicio);
            if (fin == -1) fin = json.indexOf("}", inicio);
            if (fin != -1) return json.substring(inicio, fin).trim();
        }
        return null;
    }
}

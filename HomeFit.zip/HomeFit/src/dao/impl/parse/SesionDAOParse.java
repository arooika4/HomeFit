package dao.impl.parse;

import dao.SesionDAO;
import model.Sesion;
import service.Back4AppConnection;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class SesionDAOParse implements SesionDAO {

    private static final String CLASE = "Sesion";

    // ── CREATE ────────────────────────────────────────────────────────────────
    @Override
    public void crear(Sesion sesion) {
        try {
            HttpURLConnection conn = Back4AppConnection.conectar(CLASE, "POST");

            // Back4App requiere formato ISO 8601 para fechas
            String fechaIso = sesion.getFecha().toString() + "T00:00:00.000Z";
            String json = "{\"id_sesion\":" + sesion.getIdSesion()
                        + ",\"fecha\":{\"__type\":\"Date\",\"iso\":\"" + fechaIso + "\"}}";

            try (OutputStream os = conn.getOutputStream()) {
                os.write(json.getBytes("UTF-8"));
            }

            int status = conn.getResponseCode();
            if (status == 201) {
                System.out.println("[OK] Sesion creada: " + sesion.getFecha());
            } else {
                System.out.println("[ERROR " + status + "] crear Sesion: " + leerRespuesta(conn));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ── READ (por id_sesion) ──────────────────────────────────────────────────
    @Override
    public Sesion obtener(int id) {
        try {
            HttpURLConnection conn = Back4AppConnection.conectar(
                CLASE + "?where={\"id_sesion\":" + id + "}", "GET");

            int status = conn.getResponseCode();
            String respuesta = leerRespuesta(conn);

            if (status == 200) {
                return parsearPrimera(respuesta);
            } else {
                System.out.println("[ERROR " + status + "] obtener Sesion: " + respuesta);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    // ── READ ALL ──────────────────────────────────────────────────────────────
    @Override
    public List<Sesion> obtenerTodas() {
        List<Sesion> lista = new ArrayList<>();
        try {
            HttpURLConnection conn = Back4AppConnection.conectar(CLASE, "GET");

            int status = conn.getResponseCode();
            String respuesta = leerRespuesta(conn);

            if (status == 200) {
                lista = parsearLista(respuesta);
            } else {
                System.out.println("[ERROR " + status + "] obtenerTodas Sesion: " + respuesta);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return lista;
    }

    // ── UPDATE ────────────────────────────────────────────────────────────────
    @Override
    public void actualizar(Sesion sesion) {
        try {
            String objectId = obtenerObjectId(sesion.getIdSesion());
            if (objectId == null) { System.out.println("[ERROR] Sesion no encontrada para actualizar"); return; }

            HttpURLConnection conn = Back4AppConnection.conectar(CLASE + "/" + objectId, "PUT");

            String fechaIso = sesion.getFecha().toString() + "T00:00:00.000Z";
            String json = "{\"fecha\":{\"__type\":\"Date\",\"iso\":\"" + fechaIso + "\"}}";

            try (OutputStream os = conn.getOutputStream()) {
                os.write(json.getBytes("UTF-8"));
            }

            int status = conn.getResponseCode();
            if (status == 200) {
                System.out.println("[OK] Sesion actualizada id: " + sesion.getIdSesion());
            } else {
                System.out.println("[ERROR " + status + "] actualizar Sesion: " + leerRespuesta(conn));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ── DELETE ────────────────────────────────────────────────────────────────
    @Override
    public void eliminar(int id) {
        try {
            String objectId = obtenerObjectId(id);
            if (objectId == null) { System.out.println("[ERROR] Sesion no encontrada para eliminar"); return; }

            HttpURLConnection conn = Back4AppConnection.conectar(CLASE + "/" + objectId, "DELETE");

            int status = conn.getResponseCode();
            if (status == 200) {
                System.out.println("[OK] Sesion eliminada id: " + id);
            } else {
                System.out.println("[ERROR " + status + "] eliminar Sesion: " + leerRespuesta(conn));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ── UTILIDADES ────────────────────────────────────────────────────────────

    private String obtenerObjectId(int idSesion) throws Exception {
        HttpURLConnection conn = Back4AppConnection.conectar(
            CLASE + "?where={\"id_sesion\":" + idSesion + "}&limit=1", "GET");
        String respuesta = leerRespuesta(conn);
        return extraerValor(respuesta, "objectId");
    }

    private Sesion parsearPrimera(String json) {
        if (!json.contains("\"id_sesion\"")) return null;
        Sesion s = new Sesion();
        String idStr = extraerValor(json, "id_sesion");
        if (idStr != null) s.setIdSesion(Integer.parseInt(idStr));
        // La fecha viene como "iso":"2024-01-15T00:00:00.000Z"
        String iso = extraerValor(json, "iso");
        if (iso != null) s.setFecha(LocalDate.parse(iso.substring(0, 10)));
        return s;
    }

    private List<Sesion> parsearLista(String json) {
        List<Sesion> lista = new ArrayList<>();
        String[] objetos = json.split("\\{");
        for (String obj : objetos) {
            if (obj.contains("\"id_sesion\"")) {
                Sesion s = parsearPrimera("{" + obj);
                if (s != null) lista.add(s);
            }
        }
        return lista;
    }

    private String leerRespuesta(HttpURLConnection conn) throws Exception {
        InputStream is;
        try { is = conn.getInputStream(); } catch (Exception e) { is = conn.getErrorStream(); }
        if (is == null) return "";
        Scanner sc = new Scanner(is, "UTF-8");
        StringBuilder sb = new StringBuilder();
        while (sc.hasNextLine()) sb.append(sc.nextLine());
        sc.close();
        return sb.toString();
    }

    private String extraerValor(String json, String clave) {
        String buscar = "\"" + clave + "\":\"";
        int inicio = json.indexOf(buscar);
        if (inicio != -1) {
            inicio += buscar.length();
            int fin = json.indexOf("\"", inicio);
            if (fin != -1) return json.substring(inicio, fin);
        }
        buscar = "\"" + clave + "\":";
        inicio = json.indexOf(buscar);
        if (inicio != -1) {
            inicio += buscar.length();
            int fin = json.indexOf(",", inicio);
            if (fin == -1) fin = json.indexOf("}", inicio);
            if (fin != -1) return json.substring(inicio, fin).trim();
        }
        return null;
    }
}

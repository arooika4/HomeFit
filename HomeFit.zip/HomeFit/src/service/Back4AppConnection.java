package service;

import java.net.HttpURLConnection;
import java.net.URL;

public class Back4AppConnection {

    public static final String APPLICATION_ID = "9xURsrkMwUaTPpbGwobdRaO9l76sARMxxzzqU4rP";
    public static final String REST_API_KEY   = "RcbN0lA3WtmAb1XnQ9aj5m0ydg7fQrs3hGcPtRt5";
    public static final String MASTER_KEY     = "ipTJspqWcdYuxmOgQgLf5eOgyJa3ZGmuPOsYq034";
    public static final String API_URL        = "https://parseapi.back4app.com/classes/";

    public static HttpURLConnection conectar(String endpoint, String metodo) throws Exception {
        URL url = new URL(API_URL + endpoint);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();

        conn.setRequestMethod(metodo);
        conn.setRequestProperty("X-Parse-Application-Id", APPLICATION_ID);
        conn.setRequestProperty("X-Parse-REST-API-Key", REST_API_KEY);
        conn.setRequestProperty("X-Parse-Master-Key", MASTER_KEY);
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setDoOutput(true);

        return conn;
    }
}

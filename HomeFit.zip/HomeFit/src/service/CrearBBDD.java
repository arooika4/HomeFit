package service;

import java.io.OutputStream;
import java.net.HttpURLConnection;

public class CrearBBDD {

    public static void main(String[] args) throws Exception {
        System.out.println("==============================");
        System.out.println("  Creando BBDD en Back4App   ");
        System.out.println("==============================\n");

        crearRutina();
        crearEjercicio();
        crearSesion();
        crearRegistroEjercicio();

        System.out.println("\n¡BBDD creada correctamente!");
    }

    private static void crearRutina() throws Exception {
        System.out.println("Creando clase RUTINA...");
        String body = "{\"id_rutina\":0,\"nombre\":\"tmp\"}";
        String objectId = crearClase("Rutina", body);
        if (objectId != null) {
            borrarObjeto("Rutina", objectId);
            System.out.println("  [OK] Rutina");
        }
    }

    private static void crearEjercicio() throws Exception {
        System.out.println("Creando clase EJERCICIO...");
        String body = "{\"id_ejercicio\":0,\"nombre\":\"tmp\","
                    + "\"descripcion\":\"tmp\",\"referencia\":\"tmp\","
                    + "\"id_rutina\":0}";
        String objectId = crearClase("Ejercicio", body);
        if (objectId != null) {
            borrarObjeto("Ejercicio", objectId);
            System.out.println("  [OK] Ejercicio");
        }
    }

    private static void crearSesion() throws Exception {
        System.out.println("Creando clase SESION...");
        String body = "{\"id_sesion\":0,"
                    + "\"fecha\":{\"__type\":\"Date\",\"iso\":\"2000-01-01T00:00:00.000Z\"}}";
        String objectId = crearClase("Sesion", body);
        if (objectId != null) {
            borrarObjeto("Sesion", objectId);
            System.out.println("  [OK] Sesion");
        }
    }

    private static void crearRegistroEjercicio() throws Exception {
        System.out.println("Creando clase REGISTRO_EJERCICIO...");
        String body = "{\"id_registro\":0,\"tiempo\":0,\"nivel\":0,"
                    + "\"referencia\":\"tmp\","
                    + "\"id_sesion\":0,\"id_ejercicio\":0}";
        String objectId = crearClase("RegistroEjercicio", body);
        if (objectId != null) {
            borrarObjeto("RegistroEjercicio", objectId);
            System.out.println("  [OK] RegistroEjercicio");
        }
    }

    private static String crearClase(String clase, String jsonBody) throws Exception {
        HttpURLConnection conn = Back4AppConnection.conectar(clase, "POST");
        try (OutputStream os = conn.getOutputStream()) {
            os.write(jsonBody.getBytes("UTF-8"));
        }
        int status = conn.getResponseCode();
        String respuesta = leerRespuesta(conn);
        if (status == 201) {
            String objectId = extraerValor(respuesta, "objectId");
            System.out.println("  Objeto temporal creado: " + objectId);
            return objectId;
        } else {
            System.out.println("  [ERROR " + status + "] " + clase + ": " + respuesta);
            return null;
        }
    }

    private static void borrarObjeto(String clase, String objectId) throws Exception {
        HttpURLConnection conn = Back4AppConnection.conectar(clase + "/" + objectId, "DELETE");
        int status = conn.getResponseCode();
        if (status == 200) {
            System.out.println("  Objeto temporal eliminado: " + objectId);
        } else {
            System.out.println("  [AVISO] No se pudo eliminar el objeto temporal: " + objectId);
        }
    }

    private static String leerRespuesta(HttpURLConnection conn) throws Exception {
        java.io.InputStream is;
        try { is = conn.getInputStream(); } catch (Exception e) { is = conn.getErrorStream(); }
        if (is == null) return "";
        java.util.Scanner sc = new java.util.Scanner(is, "UTF-8");
        StringBuilder sb = new StringBuilder();
        while (sc.hasNextLine()) sb.append(sc.nextLine());
        sc.close();
        return sb.toString();
    }

    private static String extraerValor(String json, String clave) {
        String buscar = "\"" + clave + "\":\"";
        int inicio = json.indexOf(buscar);
        if (inicio == -1) return null;
        inicio += buscar.length();
        int fin = json.indexOf("\"", inicio);
        if (fin == -1) return null;
        return json.substring(inicio, fin);
    }
}

package presenter;

import service.CronometroService;
import view.ICamaraView;

/**
 * Presenter de las pantallas de cámara y foto realizada (Pantallas 4 y 5).
 * Gestiona el cronómetro y el flujo de foto.
 */
public class CamaraPresenter {

    private final ICamaraView view;
    private final CronometroService cronometroService;

    private String tiempoFormateado = "00:00:00";

    public CamaraPresenter(ICamaraView view, CronometroService cronometroService) {
        this.view              = view;
        this.cronometroService = cronometroService;
    }

    /**
     * Muestra la pantalla de cámara.
     */
    public void mostrarCamara() {
        view.mostrarPantallaCamara();
    }

    /**
     * Procesa la opción de la pantalla de cámara (Pantalla 4).
     * Devuelve: "FOTO", "ATRAS", "INVALIDA"
     */
    public String procesarOpcionCamara(String opcion) {
        switch (opcion.trim()) {
            case "1":
                cronometroService.detener();
                tiempoFormateado = cronometroService.formatearTiempo();
                view.mostrarFotoRealizada(tiempoFormateado);
                return "FOTO";
            case "2": return "ATRAS";
            default:
                view.mostrarMensajeError("[Opción no reconocida]");
                return "INVALIDA";
        }
    }

    /**
     * Procesa la opción de la pantalla de foto realizada (Pantalla 5).
     * Devuelve: "REPETIR", "TERMINAR", "INVALIDA"
     */
    public String procesarOpcionFoto(String opcion) {
        switch (opcion.trim()) {
            case "1":
                cronometroService.iniciar();
                view.mostrarPantallaCamara();
                return "REPETIR";
            case "2":
                return "TERMINAR";
            default:
                view.mostrarMensajeError("[Opción no reconocida]");
                return "INVALIDA";
        }
    }

    public String getTiempoFormateado() { return tiempoFormateado; }
}

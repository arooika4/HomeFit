package presenter;

import service.HistorialService;
import service.HistorialService.RegistroSesion;
import view.IHistorialView;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Presenter de las pantallas de historial (Pantallas 6, 7 y 8).
 * Gestiona la navegación y visualización del historial de sesiones.
 */
public class HistorialPresenter {

    private final IHistorialView view;
    private final HistorialService historialService;

    // Estado de navegación
    private int indiceSesionDetalle = 0;
    private List<String> fechasCache = new ArrayList<>();
    private Map<String, List<RegistroSesion>> porFechaCache;

    // Registro actualmente en detalle ampliado (Pantalla 8)
    private RegistroSesion registroActual;

    public HistorialPresenter(IHistorialView view, HistorialService historialService) {
        this.view             = view;
        this.historialService = historialService;
    }

    // ------------------------------------------------------------------ P6 --

    /**
     * Muestra la pantalla de historial (Pantalla 6).
     */
    public void mostrarHistorial() {
        fechasCache  = historialService.obtenerFechas();
        porFechaCache = historialService.obtenerPorFecha();
        view.mostrarHistorial(fechasCache);
    }

    /**
     * Procesa la opción de la pantalla de historial.
     * Devuelve: "DETALLE_N" (N=índice fecha), "ATRAS", "INICIO", "INVALIDA"
     */
    public String procesarOpcionHistorial(String opcion) {
        int num = parseIntSafe(opcion);
        int opAtras  = fechasCache.size() + 1;
        int opInicio = fechasCache.size() + 2;

        if (num >= 1 && num <= fechasCache.size()) {
            indiceSesionDetalle = num - 1;
            mostrarDetalle();
            return "DETALLE_" + (num - 1);
        } else if (num == opAtras || num == opInicio) {
            return "ATRAS";
        } else {
            view.mostrarMensajeError("[Opción no reconocida]");
            return "INVALIDA";
        }
    }

    // ------------------------------------------------------------------ P7 --

    /**
     * Muestra el detalle de la sesión seleccionada (Pantalla 7).
     */
    public void mostrarDetalle() {
        porFechaCache = historialService.obtenerPorFecha();
        fechasCache   = historialService.obtenerFechas();

        // Mostramos máximo 2 fechas a partir del índice actual
        int contadorFoto = 1;
        for (int f = indiceSesionDetalle;
             f < Math.min(indiceSesionDetalle + 2, fechasCache.size()); f++) {

            String fecha = fechasCache.get(f);
            List<RegistroSesion> regs = porFechaCache.get(fecha);

            List<String[]> datos = new ArrayList<>();
            for (RegistroSesion r : regs) {
                datos.add(new String[]{r.ejercicio, r.tiempo, r.notas,
                                       String.valueOf(contadorFoto)});
                contadorFoto++;
            }
            view.mostrarDetalleSesion(fecha, datos);
        }
    }

    /**
     * Procesa la opción de la pantalla de detalle (Pantalla 7).
     * Devuelve: "FOTO_N", "ATRAS", "INICIO", "INVALIDA"
     */
    public String procesarOpcionDetalle(String opcion, int totalFotos) {
        int num = parseIntSafe(opcion);
        int opAtras  = totalFotos + 1;
        int opInicio = totalFotos + 2;

        if (num >= 1 && num <= totalFotos) {
            // Buscar el registro correspondiente al número de foto
            registroActual = buscarRegistroEnDetalle(num);
            if (registroActual != null) {
                view.mostrarFotoAmpliada(registroActual.ejercicio,
                                         registroActual.tiempo,
                                         registroActual.notas);
            }
            return "FOTO_" + num;
        } else if (num == opAtras) {
            return "ATRAS";
        } else if (num == opInicio) {
            return "INICIO";
        } else {
            view.mostrarMensajeError("[Opción no reconocida]");
            return "INVALIDA";
        }
    }

    // ------------------------------------------------------------------ P8 --

    /**
     * Procesa la opción de la pantalla de foto ampliada (Pantalla 8).
     * Devuelve: "NOTA_GUARDADA", "ATRAS", "INICIO", "INVALIDA"
     */
    public String procesarOpcionFotoAmpliada(String opcion, String notaNueva) {
        switch (opcion.trim()) {
            case "1":
                if (registroActual != null && notaNueva != null) {
                    registroActual.notas = notaNueva;
                    view.mostrarFotoAmpliada(registroActual.ejercicio,
                                             registroActual.tiempo,
                                             registroActual.notas);
                }
                return "NOTA_GUARDADA";
            case "2": return "ATRAS";
            case "3": return "INICIO";
            default:
                view.mostrarMensajeError("[Opción no reconocida]");
                return "INVALIDA";
        }
    }

    // ---------------------------------------------------------------- util --

    private RegistroSesion buscarRegistroEnDetalle(int numeroFoto) {
        int contador = 1;
        for (int f = indiceSesionDetalle;
             f < Math.min(indiceSesionDetalle + 2, fechasCache.size()); f++) {
            List<RegistroSesion> regs = porFechaCache.get(fechasCache.get(f));
            for (RegistroSesion r : regs) {
                if (contador == numeroFoto) return r;
                contador++;
            }
        }
        return null;
    }

    /**
     * Devuelve el número total de fotos visibles en la pantalla de detalle actual.
     */
    public int contarFotosEnDetalle() {
        porFechaCache = historialService.obtenerPorFecha();
        fechasCache   = historialService.obtenerFechas();
        int total = 0;
        for (int f = indiceSesionDetalle;
             f < Math.min(indiceSesionDetalle + 2, fechasCache.size()); f++) {
            total += porFechaCache.get(fechasCache.get(f)).size();
        }
        return total;
    }

    public RegistroSesion getRegistroActual() { return registroActual; }

    private int parseIntSafe(String s) {
        try { return Integer.parseInt(s.trim()); }
        catch (NumberFormatException e) { return -1; }
    }
}

package presenter;

import service.EjercicioService;
import service.RutinaService;
import view.IRutinaView;

import java.util.List;

/**
 * Presenter de la pantalla de rutina (Pantalla 2).
 * Gestiona la selección de ejercicio dentro de una rutina.
 */
public class RutinaPresenter {

    private final IRutinaView view;
    private final RutinaService rutinaService;
    private final EjercicioService ejercicioService;

    private int indiceRutina;
    private String nombreRutina;
    private List<String> ejercicios;

    public RutinaPresenter(IRutinaView view,
                           RutinaService rutinaService,
                           EjercicioService ejercicioService) {
        this.view             = view;
        this.rutinaService    = rutinaService;
        this.ejercicioService = ejercicioService;
    }

    /**
     * Carga la rutina indicada por índice y muestra sus ejercicios.
     */
    public void cargarRutina(int indiceRutina) {
        this.indiceRutina = indiceRutina;
        this.nombreRutina = rutinaService.obtenerNombreRutina(indiceRutina);
        this.ejercicios   = ejercicioService.obtenerEjerciciosPorRutina(indiceRutina);
        view.mostrarEjercicios(nombreRutina, ejercicios);
    }

    /**
     * Procesa la opción del usuario y devuelve el nombre del ejercicio seleccionado,
     * null si vuelve atrás/inicio, o lanza error de opción inválida.
     * Códigos: nombre del ejercicio, "ATRAS", "INICIO", "INVALIDA"
     */
    public String procesarOpcion(String opcion) {
        switch (opcion.trim()) {
            case "1": return ejercicios.get(0);
            case "2": return ejercicios.get(1);
            case "3": return ejercicios.get(2);
            case "4": return "ATRAS";
            case "5": return "INICIO";
            default:
                view.mostrarMensajeError("[Opción no reconocida]");
                return "INVALIDA";
        }
    }

    public String getNombreRutina() { return nombreRutina; }
    public int getIndiceRutina()    { return indiceRutina; }
}

# HomeFit — Con Backend Back4App (MVP)

Aplicación de consola con arquitectura Model-View-Presenter (MVP)
y persistencia real en Back4App (Parse REST API).

## Estructura de paquetes

src/
  model/               → Entidades de dominio (POJOs sin cambios)
  dao/                 → Interfaces DAO
  dao/impl/            → Implementación en memoria (Collection)
  dao/impl/parse/      → ★ Implementación Back4App (OkHttp + Gson)
  service/
    Back4AppConnection → Credenciales API
    Back4AppService    → ★ Orquesta init, carga y guardado en BBDD
    CrearBBDD          → Utilidad: crea clases en Back4App (correr 1 vez)
    RutinaService      → Nombres y estructura de rutinas
    EjercicioService   → Descripciones de ejercicios
    CronometroService  → Gestión del tiempo
    HistorialService   → Historial en memoria local sincronizado con BBDD
  view/                → Interfaces View (contrato MVP)
  presenter/           → ★ Lógica de presentación + integración backend
  ui/AppConsola        → UI "tonta": implementa las 5 interfaces View
  main/App             → ★ Punto de entrada principal
  main/Main            → Utilidad de prueba CRUD

lib/                   → JARs: okhttp, okio, gson, kotlin-stdlib

## Uso

### Paso 1 - Crear clases en Back4App (solo la primera vez):
  mkdir out
  javac -d out -cp "lib/*" -sourcepath src $(find src -name "*.java")
  java -cp "out:lib/*" service.CrearBBDD

  En Windows:
  javac -d out -cp "lib\*" -sourcepath src (Get-ChildItem -Recurse -Filter *.java | ForEach-Object { $_.FullName })
  java -cp "out;lib\*" service.CrearBBDD

### Paso 2 - Ejecutar la app:
  java -cp "out:lib/*" main.App

### Con IntelliJ IDEA:
  1. File > Open > carpeta HomeFit_MVP_Backend
  2. File > Project Structure > Libraries > añadir JARs de /lib
  3. Marcar src como Sources Root
  4. Run main.App

## Credenciales Back4App (Back4AppConnection.java)
  APPLICATION_ID = 9xURsrkMwUaTPpbGwobdRaO9l76sARMxxzzqU4rP
  REST_API_KEY   = RcbN0lA3WtmAb1XnQ9aj5m0ydg7fQrs3hGcPtRt5
  MASTER_KEY     = ipTJspqWcdYuxmOgQgLf5eOgyJa3ZGmuPOsYq034

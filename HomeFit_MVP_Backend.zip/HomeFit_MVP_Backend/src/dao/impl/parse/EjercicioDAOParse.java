package dao.impl.parse;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import dao.EjercicioDAO;
import model.Ejercicio;
import okhttp3.*;
import service.Back4AppConnection;

import java.util.ArrayList;
import java.util.List;

public class EjercicioDAOParse implements EjercicioDAO {

    private static final String CLASE = "Ejercicio";
    private final OkHttpClient client = new OkHttpClient();
    private final Gson gson = new Gson();
    private static final MediaType JSON = MediaType.get("application/json; charset=utf-8");

    @Override
    public void crear(Ejercicio ejercicio) {
        try {
            JsonObject body = new JsonObject();
            body.addProperty("id_ejercicio", ejercicio.getIdEjercicio());
            body.addProperty("nombre", ejercicio.getNombre());
            body.addProperty("descripcion", ejercicio.getDescripcion());
            body.addProperty("referencia", ejercicio.getVideoReferencia());
            body.addProperty("id_rutina", ejercicio.getIdRutina());

            Request request = new Request.Builder()
                .url(Back4AppConnection.API_URL + CLASE)
                .addHeader("X-Parse-Application-Id", Back4AppConnection.APPLICATION_ID)
                .addHeader("X-Parse-REST-API-Key", Back4AppConnection.REST_API_KEY)
                .addHeader("X-Parse-Master-Key", Back4AppConnection.MASTER_KEY)
                .addHeader("Content-Type", "application/json")
                .post(RequestBody.create(body.toString(), JSON))
                .build();

            Response response = client.newCall(request).execute();
            if (response.code() == 201) {
                System.out.println("[OK] Ejercicio creado: " + ejercicio.getNombre());
            } else {
                System.out.println("[ERROR " + response.code() + "] crear Ejercicio: " + response.body().string());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public Ejercicio obtener(int id) {
        try {
            Request request = new Request.Builder()
                .url(Back4AppConnection.API_URL + CLASE + "?where={\"id_ejercicio\":" + id + "}")
                .addHeader("X-Parse-Application-Id", Back4AppConnection.APPLICATION_ID)
                .addHeader("X-Parse-REST-API-Key", Back4AppConnection.REST_API_KEY)
                .addHeader("X-Parse-Master-Key", Back4AppConnection.MASTER_KEY)
                .get()
                .build();

            Response response = client.newCall(request).execute();
            if (response.code() == 200) {
                String json = response.body().string();
                JsonArray results = gson.fromJson(json, JsonObject.class).getAsJsonArray("results");
                if (results.size() > 0) {
                    return gson.fromJson(results.get(0), Ejercicio.class);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public List<Ejercicio> obtenerTodos() {
        List<Ejercicio> lista = new ArrayList<>();
        try {
            Request request = new Request.Builder()
                .url(Back4AppConnection.API_URL + CLASE)
                .addHeader("X-Parse-Application-Id", Back4AppConnection.APPLICATION_ID)
                .addHeader("X-Parse-REST-API-Key", Back4AppConnection.REST_API_KEY)
                .addHeader("X-Parse-Master-Key", Back4AppConnection.MASTER_KEY)
                .get()
                .build();

            Response response = client.newCall(request).execute();
            if (response.code() == 200) {
                String json = response.body().string();
                JsonArray results = gson.fromJson(json, JsonObject.class).getAsJsonArray("results");
                for (int i = 0; i < results.size(); i++) {
                    lista.add(gson.fromJson(results.get(i), Ejercicio.class));
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return lista;
    }

    @Override
    public void actualizar(Ejercicio ejercicio) {
        try {
            String objectId = obtenerObjectId(ejercicio.getIdEjercicio());
            if (objectId == null) { System.out.println("[ERROR] Ejercicio no encontrado para actualizar"); return; }

            JsonObject body = new JsonObject();
            body.addProperty("nombre", ejercicio.getNombre());
            body.addProperty("descripcion", ejercicio.getDescripcion());
            body.addProperty("referencia", ejercicio.getVideoReferencia());
            body.addProperty("id_rutina", ejercicio.getIdRutina());

            Request request = new Request.Builder()
                .url(Back4AppConnection.API_URL + CLASE + "/" + objectId)
                .addHeader("X-Parse-Application-Id", Back4AppConnection.APPLICATION_ID)
                .addHeader("X-Parse-REST-API-Key", Back4AppConnection.REST_API_KEY)
                .addHeader("X-Parse-Master-Key", Back4AppConnection.MASTER_KEY)
                .addHeader("Content-Type", "application/json")
                .put(RequestBody.create(body.toString(), JSON))
                .build();

            Response response = client.newCall(request).execute();
            if (response.code() == 200) {
                System.out.println("[OK] Ejercicio actualizado: " + ejercicio.getNombre());
            } else {
                System.out.println("[ERROR " + response.code() + "] actualizar Ejercicio: " + response.body().string());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void eliminar(int id) {
        try {
            String objectId = obtenerObjectId(id);
            if (objectId == null) { System.out.println("[ERROR] Ejercicio no encontrado para eliminar"); return; }

            Request request = new Request.Builder()
                .url(Back4AppConnection.API_URL + CLASE + "/" + objectId)
                .addHeader("X-Parse-Application-Id", Back4AppConnection.APPLICATION_ID)
                .addHeader("X-Parse-REST-API-Key", Back4AppConnection.REST_API_KEY)
                .addHeader("X-Parse-Master-Key", Back4AppConnection.MASTER_KEY)
                .delete()
                .build();

            Response response = client.newCall(request).execute();
            if (response.code() == 200) {
                System.out.println("[OK] Ejercicio eliminado id: " + id);
            } else {
                System.out.println("[ERROR " + response.code() + "] eliminar Ejercicio: " + response.body().string());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private String obtenerObjectId(int idEjercicio) throws Exception {
        Request request = new Request.Builder()
            .url(Back4AppConnection.API_URL + CLASE + "?where={\"id_ejercicio\":" + idEjercicio + "}&limit=1")
            .addHeader("X-Parse-Application-Id", Back4AppConnection.APPLICATION_ID)
            .addHeader("X-Parse-REST-API-Key", Back4AppConnection.REST_API_KEY)
            .addHeader("X-Parse-Master-Key", Back4AppConnection.MASTER_KEY)
            .get()
            .build();

        Response response = client.newCall(request).execute();
        String json = response.body().string();
        JsonArray results = gson.fromJson(json, JsonObject.class).getAsJsonArray("results");
        if (results.size() > 0) {
            return results.get(0).getAsJsonObject().get("objectId").getAsString();
        }
        return null;
    }
}

package dao.impl.parse;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import dao.RegistroEjercicioDAO;
import model.RegistroEjercicio;
import okhttp3.*;
import service.Back4AppConnection;

import java.util.ArrayList;
import java.util.List;

public class RegistroEjercicioDAOParse implements RegistroEjercicioDAO {

    private static final String CLASE = "RegistroEjercicio";
    private final OkHttpClient client = new OkHttpClient();
    private final Gson gson = new Gson();
    private static final MediaType JSON = MediaType.get("application/json; charset=utf-8");

    @Override
    public void crear(RegistroEjercicio registro) {
        try {
            JsonObject body = new JsonObject();
            body.addProperty("id_registro",  registro.getIdRegistro());
            body.addProperty("tiempo",        registro.getTiempo());
            body.addProperty("referencia",    registro.getFoto() != null ? registro.getFoto() : "");
            body.addProperty("id_sesion",     registro.getIdSesion());
            body.addProperty("id_ejercicio",  registro.getIdEjercicio());
            body.addProperty("notas",         registro.getNotas() != null ? registro.getNotas() : "");

            Request request = new Request.Builder()
                .url(Back4AppConnection.API_URL + CLASE)
                .addHeader("X-Parse-Application-Id", Back4AppConnection.APPLICATION_ID)
                .addHeader("X-Parse-REST-API-Key",   Back4AppConnection.REST_API_KEY)
                .addHeader("X-Parse-Master-Key",     Back4AppConnection.MASTER_KEY)
                .addHeader("Content-Type", "application/json")
                .post(RequestBody.create(body.toString(), JSON))
                .build();

            Response response = client.newCall(request).execute();
            if (response.code() == 201) {
                System.out.println("[OK] RegistroEjercicio creado id: " + registro.getIdRegistro());
            } else {
                System.out.println("[ERROR " + response.code() + "] crear RegistroEjercicio: " + response.body().string());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public RegistroEjercicio obtener(int id) {
        try {
            Request request = new Request.Builder()
                .url(Back4AppConnection.API_URL + CLASE + "?where={\"id_registro\":" + id + "}")
                .addHeader("X-Parse-Application-Id", Back4AppConnection.APPLICATION_ID)
                .addHeader("X-Parse-REST-API-Key",   Back4AppConnection.REST_API_KEY)
                .addHeader("X-Parse-Master-Key",     Back4AppConnection.MASTER_KEY)
                .get()
                .build();

            Response response = client.newCall(request).execute();
            if (response.code() == 200) {
                String json = response.body().string();
                JsonArray results = gson.fromJson(json, JsonObject.class).getAsJsonArray("results");
                if (results.size() > 0) {
                    return parsearRegistro(results.get(0).getAsJsonObject());
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public List<RegistroEjercicio> obtenerTodos() {
        List<RegistroEjercicio> lista = new ArrayList<>();
        try {
            Request request = new Request.Builder()
                .url(Back4AppConnection.API_URL + CLASE)
                .addHeader("X-Parse-Application-Id", Back4AppConnection.APPLICATION_ID)
                .addHeader("X-Parse-REST-API-Key",   Back4AppConnection.REST_API_KEY)
                .addHeader("X-Parse-Master-Key",     Back4AppConnection.MASTER_KEY)
                .get()
                .build();

            Response response = client.newCall(request).execute();
            if (response.code() == 200) {
                String json = response.body().string();
                JsonArray results = gson.fromJson(json, JsonObject.class).getAsJsonArray("results");
                for (int i = 0; i < results.size(); i++) {
                    lista.add(parsearRegistro(results.get(i).getAsJsonObject()));
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return lista;
    }

    @Override
    public void actualizar(RegistroEjercicio registro) {
        try {
            String objectId = obtenerObjectId(registro.getIdRegistro());
            if (objectId == null) { System.out.println("[ERROR] RegistroEjercicio no encontrado para actualizar"); return; }

            JsonObject body = new JsonObject();
            body.addProperty("tiempo",       registro.getTiempo());
            body.addProperty("referencia",   registro.getFoto() != null ? registro.getFoto() : "");
            body.addProperty("id_sesion",    registro.getIdSesion());
            body.addProperty("id_ejercicio", registro.getIdEjercicio());
            body.addProperty("notas",        registro.getNotas() != null ? registro.getNotas() : "");

            Request request = new Request.Builder()
                .url(Back4AppConnection.API_URL + CLASE + "/" + objectId)
                .addHeader("X-Parse-Application-Id", Back4AppConnection.APPLICATION_ID)
                .addHeader("X-Parse-REST-API-Key",   Back4AppConnection.REST_API_KEY)
                .addHeader("X-Parse-Master-Key",     Back4AppConnection.MASTER_KEY)
                .addHeader("Content-Type", "application/json")
                .put(RequestBody.create(body.toString(), JSON))
                .build();

            Response response = client.newCall(request).execute();
            if (response.code() == 200) {
                System.out.println("[OK] RegistroEjercicio actualizado id: " + registro.getIdRegistro());
            } else {
                System.out.println("[ERROR " + response.code() + "] actualizar RegistroEjercicio: " + response.body().string());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void eliminar(int id) {
        try {
            String objectId = obtenerObjectId(id);
            if (objectId == null) { System.out.println("[ERROR] RegistroEjercicio no encontrado para eliminar"); return; }

            Request request = new Request.Builder()
                .url(Back4AppConnection.API_URL + CLASE + "/" + objectId)
                .addHeader("X-Parse-Application-Id", Back4AppConnection.APPLICATION_ID)
                .addHeader("X-Parse-REST-API-Key",   Back4AppConnection.REST_API_KEY)
                .addHeader("X-Parse-Master-Key",     Back4AppConnection.MASTER_KEY)
                .delete()
                .build();

            Response response = client.newCall(request).execute();
            if (response.code() == 200) {
                System.out.println("[OK] RegistroEjercicio eliminado id: " + id);
            } else {
                System.out.println("[ERROR " + response.code() + "] eliminar RegistroEjercicio: " + response.body().string());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private RegistroEjercicio parsearRegistro(JsonObject obj) {
        RegistroEjercicio r = new RegistroEjercicio();
        r.setIdRegistro(obj.get("id_registro").getAsInt());
        r.setTiempo(obj.get("tiempo").getAsInt());
        r.setIdSesion(obj.get("id_sesion").getAsInt());
        r.setIdEjercicio(obj.get("id_ejercicio").getAsInt());
        if (obj.has("referencia") && !obj.get("referencia").isJsonNull()) {
            r.setFoto(obj.get("referencia").getAsString());
        }
        if (obj.has("notas") && !obj.get("notas").isJsonNull()) {
            r.setNotas(obj.get("notas").getAsString());
        }
        return r;
    }

    private String obtenerObjectId(int idRegistro) throws Exception {
        Request request = new Request.Builder()
            .url(Back4AppConnection.API_URL + CLASE + "?where={\"id_registro\":" + idRegistro + "}&limit=1")
            .addHeader("X-Parse-Application-Id", Back4AppConnection.APPLICATION_ID)
            .addHeader("X-Parse-REST-API-Key",   Back4AppConnection.REST_API_KEY)
            .addHeader("X-Parse-Master-Key",     Back4AppConnection.MASTER_KEY)
            .get()
            .build();

        Response response = client.newCall(request).execute();
        String json = response.body().string();
        JsonArray results = gson.fromJson(json, JsonObject.class).getAsJsonArray("results");
        if (results.size() > 0) {
            return results.get(0).getAsJsonObject().get("objectId").getAsString();
        }
        return null;
    }
}
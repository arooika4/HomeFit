package dao.impl.parse;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import dao.RutinaDAO;
import model.Rutina;
import okhttp3.*;
import service.Back4AppConnection;

import java.util.ArrayList;
import java.util.List;

public class RutinaDAOParse implements RutinaDAO {

    private static final String CLASE = "Rutina";
    private final OkHttpClient client = new OkHttpClient();
    private final Gson gson = new Gson();
    private static final MediaType JSON = MediaType.get("application/json; charset=utf-8");

    @Override
    public void crear(Rutina rutina) {
        try {
            JsonObject body = new JsonObject();
            body.addProperty("id_rutina", rutina.getIdRutina());
            body.addProperty("nombre", rutina.getNombre());

            Request request = new Request.Builder()
                .url(Back4AppConnection.API_URL + CLASE)
                .addHeader("X-Parse-Application-Id", Back4AppConnection.APPLICATION_ID)
                .addHeader("X-Parse-REST-API-Key", Back4AppConnection.REST_API_KEY)
                .addHeader("X-Parse-Master-Key", Back4AppConnection.MASTER_KEY)
                .addHeader("Content-Type", "application/json")
                .post(RequestBody.create(body.toString(), JSON))
                .build();

            Response response = client.newCall(request).execute();
            if (response.code() == 201) {
                System.out.println("[OK] Rutina creada: " + rutina.getNombre());
            } else {
                System.out.println("[ERROR " + response.code() + "] crear Rutina: " + response.body().string());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public Rutina obtener(int id) {
        try {
            Request request = new Request.Builder()
                .url(Back4AppConnection.API_URL + CLASE + "?where={\"id_rutina\":" + id + "}")
                .addHeader("X-Parse-Application-Id", Back4AppConnection.APPLICATION_ID)
                .addHeader("X-Parse-REST-API-Key", Back4AppConnection.REST_API_KEY)
                .addHeader("X-Parse-Master-Key", Back4AppConnection.MASTER_KEY)
                .get()
                .build();

            Response response = client.newCall(request).execute();
            if (response.code() == 200) {
                String json = response.body().string();
                JsonArray results = gson.fromJson(json, JsonObject.class).getAsJsonArray("results");
                if (results.size() > 0) {
                    return gson.fromJson(results.get(0), Rutina.class);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public List<Rutina> obtenerTodas() {
        List<Rutina> lista = new ArrayList<>();
        try {
            Request request = new Request.Builder()
                .url(Back4AppConnection.API_URL + CLASE)
                .addHeader("X-Parse-Application-Id", Back4AppConnection.APPLICATION_ID)
                .addHeader("X-Parse-REST-API-Key", Back4AppConnection.REST_API_KEY)
                .addHeader("X-Parse-Master-Key", Back4AppConnection.MASTER_KEY)
                .get()
                .build();

            Response response = client.newCall(request).execute();
            if (response.code() == 200) {
                String json = response.body().string();
                JsonArray results = gson.fromJson(json, JsonObject.class).getAsJsonArray("results");
                for (int i = 0; i < results.size(); i++) {
                    lista.add(gson.fromJson(results.get(i), Rutina.class));
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return lista;
    }

    @Override
    public void actualizar(Rutina rutina) {
        try {
            String objectId = obtenerObjectId(rutina.getIdRutina());
            if (objectId == null) { System.out.println("[ERROR] Rutina no encontrada para actualizar"); return; }

            JsonObject body = new JsonObject();
            body.addProperty("nombre", rutina.getNombre());

            Request request = new Request.Builder()
                .url(Back4AppConnection.API_URL + CLASE + "/" + objectId)
                .addHeader("X-Parse-Application-Id", Back4AppConnection.APPLICATION_ID)
                .addHeader("X-Parse-REST-API-Key", Back4AppConnection.REST_API_KEY)
                .addHeader("X-Parse-Master-Key", Back4AppConnection.MASTER_KEY)
                .addHeader("Content-Type", "application/json")
                .put(RequestBody.create(body.toString(), JSON))
                .build();

            Response response = client.newCall(request).execute();
            if (response.code() == 200) {
                System.out.println("[OK] Rutina actualizada: " + rutina.getNombre());
            } else {
                System.out.println("[ERROR " + response.code() + "] actualizar Rutina: " + response.body().string());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void eliminar(int id) {
        try {
            String objectId = obtenerObjectId(id);
            if (objectId == null) { System.out.println("[ERROR] Rutina no encontrada para eliminar"); return; }

            Request request = new Request.Builder()
                .url(Back4AppConnection.API_URL + CLASE + "/" + objectId)
                .addHeader("X-Parse-Application-Id", Back4AppConnection.APPLICATION_ID)
                .addHeader("X-Parse-REST-API-Key", Back4AppConnection.REST_API_KEY)
                .addHeader("X-Parse-Master-Key", Back4AppConnection.MASTER_KEY)
                .delete()
                .build();

            Response response = client.newCall(request).execute();
            if (response.code() == 200) {
                System.out.println("[OK] Rutina eliminada id: " + id);
            } else {
                System.out.println("[ERROR " + response.code() + "] eliminar Rutina: " + response.body().string());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private String obtenerObjectId(int idRutina) throws Exception {
        Request request = new Request.Builder()
            .url(Back4AppConnection.API_URL + CLASE + "?where={\"id_rutina\":" + idRutina + "}&limit=1")
            .addHeader("X-Parse-Application-Id", Back4AppConnection.APPLICATION_ID)
            .addHeader("X-Parse-REST-API-Key", Back4AppConnection.REST_API_KEY)
            .addHeader("X-Parse-Master-Key", Back4AppConnection.MASTER_KEY)
            .get()
            .build();

        Response response = client.newCall(request).execute();
        String json = response.body().string();
        JsonArray results = gson.fromJson(json, JsonObject.class).getAsJsonArray("results");
        if (results.size() > 0) {
            return results.get(0).getAsJsonObject().get("objectId").getAsString();
        }
        return null;
    }
}

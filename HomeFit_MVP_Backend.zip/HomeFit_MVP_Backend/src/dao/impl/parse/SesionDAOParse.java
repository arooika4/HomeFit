package dao.impl.parse;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import dao.SesionDAO;
import model.Sesion;
import okhttp3.*;
import service.Back4AppConnection;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class SesionDAOParse implements SesionDAO {

    private static final String CLASE = "Sesion";
    private final OkHttpClient client = new OkHttpClient();
    private final Gson gson = new Gson();
    private static final MediaType JSON = MediaType.get("application/json; charset=utf-8");

    @Override
    public void crear(Sesion sesion) {
        try {
            JsonObject fecha = new JsonObject();
            fecha.addProperty("__type", "Date");
            fecha.addProperty("iso", sesion.getFecha().toString() + "T00:00:00.000Z");

            JsonObject body = new JsonObject();
            body.addProperty("id_sesion", sesion.getIdSesion());
            body.add("fecha", fecha);

            Request request = new Request.Builder()
                .url(Back4AppConnection.API_URL + CLASE)
                .addHeader("X-Parse-Application-Id", Back4AppConnection.APPLICATION_ID)
                .addHeader("X-Parse-REST-API-Key", Back4AppConnection.REST_API_KEY)
                .addHeader("X-Parse-Master-Key", Back4AppConnection.MASTER_KEY)
                .addHeader("Content-Type", "application/json")
                .post(RequestBody.create(body.toString(), JSON))
                .build();

            Response response = client.newCall(request).execute();
            if (response.code() == 201) {
                System.out.println("[OK] Sesion creada: " + sesion.getFecha());
            } else {
                System.out.println("[ERROR " + response.code() + "] crear Sesion: " + response.body().string());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public Sesion obtener(int id) {
        try {
            Request request = new Request.Builder()
                .url(Back4AppConnection.API_URL + CLASE + "?where={\"id_sesion\":" + id + "}")
                .addHeader("X-Parse-Application-Id", Back4AppConnection.APPLICATION_ID)
                .addHeader("X-Parse-REST-API-Key", Back4AppConnection.REST_API_KEY)
                .addHeader("X-Parse-Master-Key", Back4AppConnection.MASTER_KEY)
                .get()
                .build();

            Response response = client.newCall(request).execute();
            if (response.code() == 200) {
                String json = response.body().string();
                JsonArray results = gson.fromJson(json, JsonObject.class).getAsJsonArray("results");
                if (results.size() > 0) {
                    return parsearSesion(results.get(0).getAsJsonObject());
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public List<Sesion> obtenerTodas() {
        List<Sesion> lista = new ArrayList<>();
        try {
            Request request = new Request.Builder()
                .url(Back4AppConnection.API_URL + CLASE)
                .addHeader("X-Parse-Application-Id", Back4AppConnection.APPLICATION_ID)
                .addHeader("X-Parse-REST-API-Key", Back4AppConnection.REST_API_KEY)
                .addHeader("X-Parse-Master-Key", Back4AppConnection.MASTER_KEY)
                .get()
                .build();

            Response response = client.newCall(request).execute();
            if (response.code() == 200) {
                String json = response.body().string();
                JsonArray results = gson.fromJson(json, JsonObject.class).getAsJsonArray("results");
                for (int i = 0; i < results.size(); i++) {
                    lista.add(parsearSesion(results.get(i).getAsJsonObject()));
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return lista;
    }

    @Override
    public void actualizar(Sesion sesion) {
        try {
            String objectId = obtenerObjectId(sesion.getIdSesion());
            if (objectId == null) { System.out.println("[ERROR] Sesion no encontrada para actualizar"); return; }

            JsonObject fecha = new JsonObject();
            fecha.addProperty("__type", "Date");
            fecha.addProperty("iso", sesion.getFecha().toString() + "T00:00:00.000Z");

            JsonObject body = new JsonObject();
            body.add("fecha", fecha);

            Request request = new Request.Builder()
                .url(Back4AppConnection.API_URL + CLASE + "/" + objectId)
                .addHeader("X-Parse-Application-Id", Back4AppConnection.APPLICATION_ID)
                .addHeader("X-Parse-REST-API-Key", Back4AppConnection.REST_API_KEY)
                .addHeader("X-Parse-Master-Key", Back4AppConnection.MASTER_KEY)
                .addHeader("Content-Type", "application/json")
                .put(RequestBody.create(body.toString(), JSON))
                .build();

            Response response = client.newCall(request).execute();
            if (response.code() == 200) {
                System.out.println("[OK] Sesion actualizada id: " + sesion.getIdSesion());
            } else {
                System.out.println("[ERROR " + response.code() + "] actualizar Sesion: " + response.body().string());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void eliminar(int id) {
        try {
            String objectId = obtenerObjectId(id);
            if (objectId == null) { System.out.println("[ERROR] Sesion no encontrada para eliminar"); return; }

            Request request = new Request.Builder()
                .url(Back4AppConnection.API_URL + CLASE + "/" + objectId)
                .addHeader("X-Parse-Application-Id", Back4AppConnection.APPLICATION_ID)
                .addHeader("X-Parse-REST-API-Key", Back4AppConnection.REST_API_KEY)
                .addHeader("X-Parse-Master-Key", Back4AppConnection.MASTER_KEY)
                .delete()
                .build();

            Response response = client.newCall(request).execute();
            if (response.code() == 200) {
                System.out.println("[OK] Sesion eliminada id: " + id);
            } else {
                System.out.println("[ERROR " + response.code() + "] eliminar Sesion: " + response.body().string());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private Sesion parsearSesion(JsonObject obj) {
        Sesion s = new Sesion();
        s.setIdSesion(obj.get("id_sesion").getAsInt());
        if (obj.has("fecha") && !obj.get("fecha").isJsonNull()) {
            String iso = obj.getAsJsonObject("fecha").get("iso").getAsString();
            s.setFecha(LocalDate.parse(iso.substring(0, 10)));
        }
        return s;
    }

    private String obtenerObjectId(int idSesion) throws Exception {
        Request request = new Request.Builder()
            .url(Back4AppConnection.API_URL + CLASE + "?where={\"id_sesion\":" + idSesion + "}&limit=1")
            .addHeader("X-Parse-Application-Id", Back4AppConnection.APPLICATION_ID)
            .addHeader("X-Parse-REST-API-Key", Back4AppConnection.REST_API_KEY)
            .addHeader("X-Parse-Master-Key", Back4AppConnection.MASTER_KEY)
            .get()
            .build();

        Response response = client.newCall(request).execute();
        String json = response.body().string();
        JsonArray results = gson.fromJson(json, JsonObject.class).getAsJsonArray("results");
        if (results.size() > 0) {
            return results.get(0).getAsJsonObject().get("objectId").getAsString();
        }
        return null;
    }
}

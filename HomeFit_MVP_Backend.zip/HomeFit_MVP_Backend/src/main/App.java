package main;

import ui.AppConsola;

/**
 * Punto de entrada de HomeFit con backend Back4App.
 * Arranca la AppConsola que carga datos desde la BBDD y lanza la UI.
 */
public class App {
    public static void main(String[] args) {
        AppConsola app = new AppConsola();
        app.iniciar();
    }
}

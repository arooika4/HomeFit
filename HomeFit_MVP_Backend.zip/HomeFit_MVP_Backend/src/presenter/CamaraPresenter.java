package presenter;

import service.Back4AppService;
import service.CronometroService;
import service.HistorialService;
import view.ICamaraView;

/**
 * Presenter de las pantallas de cámara y foto realizada (Pantallas 4 y 5).
 * En la versión con backend, al terminar el ejercicio persiste en Back4App
 * a través de Back4AppService y actualiza el HistorialService local.
 */
public class CamaraPresenter {

    private final ICamaraView       view;
    private final CronometroService cronometroService;
    private final Back4AppService   back4AppService;
    private final HistorialService  historialService;

    private String tiempoFormateado = "00:00:00";

    // datos del ejercicio activo (setados por RutinaPresenter antes de llegar aquí)
    private int    idEjercicioActivo  = -1;
    private String nombreEjercicioActivo = "";

    public CamaraPresenter(ICamaraView view,
                           CronometroService cronometroService,
                           Back4AppService back4AppService,
                           HistorialService historialService) {
        this.view              = view;
        this.cronometroService = cronometroService;
        this.back4AppService   = back4AppService;
        this.historialService  = historialService;
    }

    /** Llamado por el flujo de navegación antes de entrar a la cámara. */
    public void setEjercicioActivo(int idEjercicio, String nombreEjercicio) {
        this.idEjercicioActivo    = idEjercicio;
        this.nombreEjercicioActivo = nombreEjercicio;
    }

    public void mostrarCamara() {
        view.mostrarPantallaCamara();
    }

    /**
     * Procesa opción Pantalla 4 (cámara).
     * Devuelve: "FOTO", "ATRAS", "INVALIDA"
     */
    public String procesarOpcionCamara(String opcion) {
        switch (opcion.trim()) {
            case "1":
                cronometroService.detener();
                tiempoFormateado = cronometroService.formatearTiempo();
                view.mostrarFotoRealizada(tiempoFormateado);
                return "FOTO";
            case "2": return "ATRAS";
            default:
                view.mostrarMensajeError("[Opción no reconocida]");
                return "INVALIDA";
        }
    }

    /**
     * Procesa opción Pantalla 5 (foto realizada).
     * Devuelve: "REPETIR", "TERMINAR", "INVALIDA"
     *
     * Al terminar: persiste en Back4App y actualiza historial local.
     */
    public String procesarOpcionFoto(String opcion, String fechaHoy) {
        switch (opcion.trim()) {
            case "1":
                cronometroService.iniciar();
                view.mostrarPantallaCamara();
                return "REPETIR";
            case "2":
                System.out.println("  Guardando en la base de datos...");
                int idRegistro = back4AppService.guardarEjercicioRealizado(
                    idEjercicioActivo,
                    cronometroService.getTiempoTranscurridoMs(),
                    ""
                );
                historialService.agregarRegistro(
                    nombreEjercicioActivo,
                    tiempoFormateado,
                    fechaHoy,
                    idRegistro
                );
                System.out.println("  Ejercicio guardado correctamente");
                return "TERMINAR";
            default:
                view.mostrarMensajeError("[Opción no reconocida]");
                return "INVALIDA";
        }
    }

    public String getTiempoFormateado() { return tiempoFormateado; }
}

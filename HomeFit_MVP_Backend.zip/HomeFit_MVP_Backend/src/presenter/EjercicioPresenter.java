package presenter;

import service.EjercicioService;
import view.IEjercicioView;

/**
 * Presenter de la pantalla de ejercicio (Pantalla 3).
 * Gestiona la visualización del detalle del ejercicio y acciones disponibles.
 */
public class EjercicioPresenter {

    private final IEjercicioView view;
    private final EjercicioService ejercicioService;

    private String nombreEjercicio;

    public EjercicioPresenter(IEjercicioView view, EjercicioService ejercicioService) {
        this.view             = view;
        this.ejercicioService = ejercicioService;
    }

    /**
     * Carga el ejercicio y muestra su detalle completo.
     */
    public void cargarEjercicio(String nombreEjercicio) {
        this.nombreEjercicio = nombreEjercicio;
        String descripcion = ejercicioService.obtenerDescripcion(nombreEjercicio);
        view.mostrarDetalleEjercicio(nombreEjercicio, descripcion);
    }

    /**
     * Procesa la opción seleccionada.
     * Devuelve: "VIDEO", "CAMARA", "ATRAS", "INICIO", "INVALIDA"
     */
    public String procesarOpcion(String opcion) {
        switch (opcion.trim()) {
            case "1":
                view.mostrarVideoSimulado(nombreEjercicio);
                return "VIDEO";
            case "2": return "CAMARA";
            case "3": return "ATRAS";
            case "4": return "INICIO";
            default:
                view.mostrarMensajeError("[Opción no reconocida]");
                return "INVALIDA";
        }
    }

    public String getNombreEjercicio() { return nombreEjercicio; }
}

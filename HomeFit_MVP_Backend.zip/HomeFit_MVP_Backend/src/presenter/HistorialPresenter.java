package presenter;

import service.Back4AppService;
import service.HistorialService;
import service.HistorialService.RegistroSesion;
import view.IHistorialView;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Presenter de las pantallas de historial (Pantallas 6, 7 y 8).
 * En la versión con backend, delega la actualización de notas a Back4AppService.
 */
public class HistorialPresenter {

    private final IHistorialView   view;
    private final HistorialService historialService;
    private final Back4AppService  back4AppService;

    private int indiceSesionDetalle = 0;
    private List<String> fechasCache = new ArrayList<>();
    private Map<String, List<RegistroSesion>> porFechaCache;
    private RegistroSesion registroActual;

    public HistorialPresenter(IHistorialView view,
                              HistorialService historialService,
                              Back4AppService back4AppService) {
        this.view             = view;
        this.historialService = historialService;
        this.back4AppService  = back4AppService;
    }

    // ------------------------------------------------------------------ P6 --

    public void mostrarHistorial() {
        fechasCache   = historialService.obtenerFechas();
        porFechaCache = historialService.obtenerPorFecha();
        view.mostrarHistorial(fechasCache);
    }

    public String procesarOpcionHistorial(String opcion) {
        int num      = parseIntSafe(opcion);
        int opAtras  = fechasCache.size() + 1;
        int opInicio = fechasCache.size() + 2;

        if (num >= 1 && num <= fechasCache.size()) {
            indiceSesionDetalle = num - 1;
            mostrarDetalle();
            return "DETALLE_" + (num - 1);
        } else if (num == opAtras || num == opInicio) {
            return "ATRAS";
        } else {
            view.mostrarMensajeError("[Opción no reconocida]");
            return "INVALIDA";
        }
    }

    // ------------------------------------------------------------------ P7 --

    public void mostrarDetalle() {
        porFechaCache = historialService.obtenerPorFecha();
        fechasCache   = historialService.obtenerFechas();

        for (int f = indiceSesionDetalle;
             f < Math.min(indiceSesionDetalle + 2, fechasCache.size()); f++) {

            String fecha = fechasCache.get(f);
            List<RegistroSesion> regs = porFechaCache.get(fecha);

            List<String[]> datos = new ArrayList<>();
            int contadorFoto = 1;
            for (RegistroSesion r : regs) {
                datos.add(new String[]{r.ejercicio, r.tiempo, r.notas,
                                       String.valueOf(contadorFoto)});
                contadorFoto++;
            }
            view.mostrarDetalleSesion(fecha, datos);
        }
    }

    public String procesarOpcionDetalle(String opcion, int totalFotos) {
        int num      = parseIntSafe(opcion);
        int opAtras  = totalFotos + 1;
        int opInicio = totalFotos + 2;

        if (num >= 1 && num <= totalFotos) {
            registroActual = buscarRegistroEnDetalle(num);
            if (registroActual != null) {
                view.mostrarFotoAmpliada(registroActual.ejercicio,
                                         registroActual.tiempo,
                                         registroActual.notas);
            }
            return "FOTO_" + num;
        } else if (num == opAtras) {
            return "ATRAS";
        } else if (num == opInicio) {
            return "INICIO";
        } else {
            view.mostrarMensajeError("[Opción no reconocida]");
            return "INVALIDA";
        }
    }

    // ------------------------------------------------------------------ P8 --

    public String procesarOpcionFotoAmpliada(String opcion, String notaNueva) {
        switch (opcion.trim()) {
            case "1":
                if (registroActual != null && notaNueva != null) {
                    registroActual.notas = notaNueva;
                    // Persistir en Back4App
                    back4AppService.actualizarNotas(registroActual.idRegistro, notaNueva);
                    view.mostrarFotoAmpliada(registroActual.ejercicio,
                                             registroActual.tiempo,
                                             registroActual.notas);
                }
                return "NOTA_GUARDADA";
            case "2": return "ATRAS";
            case "3": return "INICIO";
            default:
                view.mostrarMensajeError("[Opción no reconocida]");
                return "INVALIDA";
        }
    }

    // ---------------------------------------------------------------- util --

    private RegistroSesion buscarRegistroEnDetalle(int numeroFoto) {
        int contador = 1;
        for (int f = indiceSesionDetalle;
             f < Math.min(indiceSesionDetalle + 2, fechasCache.size()); f++) {
            for (RegistroSesion r : porFechaCache.get(fechasCache.get(f))) {
                if (contador == numeroFoto) return r;
                contador++;
            }
        }
        return null;
    }

    public int contarFotosEnDetalle() {
        porFechaCache = historialService.obtenerPorFecha();
        fechasCache   = historialService.obtenerFechas();
        int total = 0;
        for (int f = indiceSesionDetalle;
             f < Math.min(indiceSesionDetalle + 2, fechasCache.size()); f++) {
            total += porFechaCache.get(fechasCache.get(f)).size();
        }
        return total;
    }

    public RegistroSesion getRegistroActual() { return registroActual; }

    private int parseIntSafe(String s) {
        try { return Integer.parseInt(s.trim()); }
        catch (NumberFormatException e) { return -1; }
    }
}

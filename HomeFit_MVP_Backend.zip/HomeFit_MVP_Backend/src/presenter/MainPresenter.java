package presenter;

import service.RutinaService;
import view.IMainView;

/**
 * Presenter de la pantalla principal (Pantalla 1).
 * Recibe acciones del usuario, coordina con el Service y actualiza la View.
 */
public class MainPresenter {

    private final IMainView view;
    private final RutinaService rutinaService;

    public MainPresenter(IMainView view, RutinaService rutinaService) {
        this.view          = view;
        this.rutinaService = rutinaService;
    }

    /**
     * Muestra el menú principal.
     */
    public void mostrarMenu() {
        view.mostrarMenuPrincipal();
    }

    /**
     * Valida la opción seleccionada y devuelve el índice de rutina (0-based),
     * -1 si es historial, -2 si es salir, -3 si es inválida.
     */
    public int procesarOpcion(String opcion) {
        switch (opcion.trim()) {
            case "1": return 0;   // Tren superior
            case "2": return 1;   // Tren inferior
            case "3": return 2;   // Core
            case "4": return -1;  // Historial
            case "5": return -2;  // Salir
            default:
                view.mostrarMensajeError("[Opción no reconocida]");
                return -3;
        }
    }
}

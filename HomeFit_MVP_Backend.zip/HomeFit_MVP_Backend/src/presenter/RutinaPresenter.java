package presenter;

import service.Back4AppService;
import service.EjercicioService;
import service.RutinaService;
import view.IRutinaView;

import java.util.List;

/**
 * Presenter de la pantalla de rutina (Pantalla 2).
 * En la versión con backend también conoce los IDs de ejercicio
 * para pasarlos al CamaraPresenter al seleccionar un ejercicio.
 */
public class RutinaPresenter {

    private final IRutinaView      view;
    private final RutinaService    rutinaService;
    private final EjercicioService ejercicioService;
    private final Back4AppService  back4AppService;

    private int          indiceRutina;
    private String       nombreRutina;
    private List<String> ejercicios;

    public RutinaPresenter(IRutinaView view,
                           RutinaService rutinaService,
                           EjercicioService ejercicioService,
                           Back4AppService back4AppService) {
        this.view             = view;
        this.rutinaService    = rutinaService;
        this.ejercicioService = ejercicioService;
        this.back4AppService  = back4AppService;
    }

    public void cargarRutina(int indiceRutina) {
        this.indiceRutina = indiceRutina;
        this.nombreRutina = rutinaService.obtenerNombreRutina(indiceRutina);
        this.ejercicios   = ejercicioService.obtenerEjerciciosPorRutina(indiceRutina);
        view.mostrarEjercicios(nombreRutina, ejercicios);
    }

    /**
     * Procesa la opción seleccionada.
     * Devuelve el nombre del ejercicio elegido, o "ATRAS"/"INICIO"/"INVALIDA".
     */
    public String procesarOpcion(String opcion) {
        switch (opcion.trim()) {
            case "1": return ejercicios.get(0);
            case "2": return ejercicios.get(1);
            case "3": return ejercicios.get(2);
            case "4": return "ATRAS";
            case "5": return "INICIO";
            default:
                view.mostrarMensajeError("[Opción no reconocida]");
                return "INVALIDA";
        }
    }

    /**
     * Devuelve el ID de Back4App del ejercicio seleccionado por índice (0-based).
     */
    public int getIdEjercicio(int indiceEjercicio) {
        return back4AppService.getIdEjercicio(indiceRutina, indiceEjercicio);
    }

    public String getNombreRutina() { return nombreRutina; }
    public int    getIndiceRutina() { return indiceRutina; }
}

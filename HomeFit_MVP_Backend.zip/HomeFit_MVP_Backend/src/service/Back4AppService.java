package service;

import dao.impl.parse.EjercicioDAOParse;
import dao.impl.parse.RegistroEjercicioDAOParse;
import dao.impl.parse.RutinaDAOParse;
import dao.impl.parse.SesionDAOParse;
import model.Ejercicio;
import model.RegistroEjercicio;
import model.Rutina;
import model.Sesion;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

/**
 * Service layer: orquesta toda la comunicación con Back4App.
 *
 * Responsabilidades:
 *  - Inicializar rutinas y ejercicios en BBDD si no existen.
 *  - Cargar el historial desde la BBDD al arrancar.
 *  - Guardar sesiones y registros de ejercicio al terminar.
 *  - Actualizar notas de un registro en BBDD.
 *
 * Los Presenters llaman a este servicio; nunca tocan los DAO directamente.
 */
public class Back4AppService {

    // ---------------------------------------------------------------- DAOs --
    private final RutinaDAOParse            rutinaDAO    = new RutinaDAOParse();
    private final EjercicioDAOParse         ejercicioDAO = new EjercicioDAOParse();
    private final SesionDAOParse            sesionDAO    = new SesionDAOParse();
    private final RegistroEjercicioDAOParse registroDAO  = new RegistroEjercicioDAOParse();

    // --------------------------------------------------------- IDs estáticos --
    // id_rutina: 1=Tren superior  2=Tren inferior  3=Core
    public static final int[]      IDS_RUTINA    = {1, 2, 3};
    public static final String[]   NOMBRES_RUTINA = {"Tren superior", "Tren inferior", "Core"};

    // id_ejercicio: 1-3 tren sup | 4-6 tren inf | 7-9 core
    public static final int[][]    IDS_EJERCICIO = {{1,2,3},{4,5,6},{7,8,9}};
    public static final String[][] EJERCICIOS_POR_RUTINA = {
        {"Push up tradicional", "Vuelo lateral", "Fondos de tríceps"},
        {"Sentadilla con peso corporal", "Estocada búlgara", "Puente de glúteo"},
        {"Bicicleta abdominal", "Crunch abdominal", "Plancha"}
    };

    // --------------------------------------------------- Contadores de IDs --
    private int proximoIdSesion   = 1;
    private int proximoIdRegistro = 1;

    // ======================================================= API pública ===

    /**
     * Asegura que rutinas y ejercicios existen en BBDD.
     * Llámalo una vez al arrancar la aplicación.
     */
    public void inicializarDatos() {
        List<Rutina> rutinasEnBBDD = rutinaDAO.obtenerTodas();
        for (int i = 0; i < IDS_RUTINA.length; i++) {
            final String nombre = NOMBRES_RUTINA[i];
            boolean existe = rutinasEnBBDD.stream().anyMatch(r -> nombre.equals(r.getNombre()));
            if (!existe) {
                rutinaDAO.crear(new Rutina(IDS_RUTINA[i], nombre));
            }
        }

        List<Ejercicio> ejerciciosEnBBDD = ejercicioDAO.obtenerTodos();
        for (int i = 0; i < IDS_EJERCICIO.length; i++) {
            for (int j = 0; j < IDS_EJERCICIO[i].length; j++) {
                final String nombreEj = EJERCICIOS_POR_RUTINA[i][j];
                boolean existe = ejerciciosEnBBDD.stream().anyMatch(e -> nombreEj.equals(e.getNombre()));
                if (!existe) {
                    Ejercicio e = new Ejercicio(IDS_EJERCICIO[i][j], nombreEj);
                    e.setIdRutina(IDS_RUTINA[i]);
                    ejercicioDAO.crear(e);
                }
            }
        }
    }

    /**
     * Carga el historial completo desde Back4App.
     * Devuelve lista de RegistroSesion con toda la info cruzada.
     */
    public List<HistorialService.RegistroSesion> cargarHistorial() {
        List<HistorialService.RegistroSesion> resultado = new ArrayList<>();

        List<Sesion> sesiones           = sesionDAO.obtenerTodas();
        List<RegistroEjercicio> registros = registroDAO.obtenerTodos();
        List<Ejercicio> ejercicios      = ejercicioDAO.obtenerTodos();

        // Actualizar contadores
        for (Sesion s : sesiones) {
            if (s.getIdSesion() >= proximoIdSesion) proximoIdSesion = s.getIdSesion() + 1;
        }
        for (RegistroEjercicio reg : registros) {
            if (reg.getIdRegistro() >= proximoIdRegistro) proximoIdRegistro = reg.getIdRegistro() + 1;
        }

        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("dd/MM/yyyy");

        for (RegistroEjercicio reg : registros) {
            Sesion sesion = sesiones.stream()
                .filter(s -> s.getIdSesion() == reg.getIdSesion())
                .findFirst().orElse(null);

            Ejercicio ej = ejercicios.stream()
                .filter(e -> e.getIdEjercicio() == reg.getIdEjercicio())
                .findFirst().orElse(null);

            String nombreEj = (ej != null && ej.getNombre() != null && !ej.getNombre().isEmpty())
                ? ej.getNombre()
                : buscarNombreEjercicioLocal(reg.getIdEjercicio());

            String fecha = (sesion != null && sesion.getFecha() != null)
                ? sesion.getFecha().format(fmt)
                : "Sin fecha";

            String tiempo = CronometroService.formatearTiempo((long) reg.getTiempo() * 1000L);

            HistorialService.RegistroSesion rs =
                new HistorialService.RegistroSesion(nombreEj, tiempo, fecha);
            rs.notas     = (reg.getNotas() != null) ? reg.getNotas() : "";
            rs.idRegistro = reg.getIdRegistro();

            resultado.add(rs);
        }

        return resultado;
    }

    /**
     * Persiste una sesión + registro de ejercicio en Back4App.
     *
     * @param idEjercicio  ID del ejercicio realizado
     * @param tiempoMs     tiempo transcurrido en milisegundos
     * @param notas        notas iniciales (puede ser "")
     * @return             idRegistro asignado
     */
    public int guardarEjercicioRealizado(int idEjercicio, long tiempoMs, String notas) {
        // Sesión
        int idSesion = proximoIdSesion++;
        Sesion sesion = new Sesion(idSesion, LocalDate.now());
        sesionDAO.crear(sesion);

        // Registro
        int idRegistro = proximoIdRegistro++;
        RegistroEjercicio reg = new RegistroEjercicio();
        reg.setIdRegistro(idRegistro);
        reg.setIdSesion(idSesion);
        reg.setIdEjercicio(idEjercicio);
        reg.setTiempo((int) (tiempoMs / 1000));
        reg.setFoto("");
        reg.setNotas(notas != null ? notas : "");
        registroDAO.crear(reg);

        return idRegistro;
    }

    /**
     * Actualiza las notas de un registro existente en Back4App.
     */
    public void actualizarNotas(int idRegistro, String notas) {
        if (idRegistro <= 0) return;
        try {
            RegistroEjercicio reg = registroDAO.obtener(idRegistro);
            if (reg == null) return;
            reg.setNotas(notas);
            registroDAO.actualizar(reg);
        } catch (Exception e) {
            System.out.println("[ERROR] No se pudo guardar la nota: " + e.getMessage());
        }
    }

    /**
     * Devuelve el id de ejercicio dado el índice de rutina y el índice de ejercicio.
     */
    public int getIdEjercicio(int indiceRutina, int indiceEjercicio) {
        return IDS_EJERCICIO[indiceRutina][indiceEjercicio];
    }

    // ------------------------------------------------------------ privado --

    private String buscarNombreEjercicioLocal(int idEjercicio) {
        for (int i = 0; i < IDS_EJERCICIO.length; i++) {
            for (int j = 0; j < IDS_EJERCICIO[i].length; j++) {
                if (IDS_EJERCICIO[i][j] == idEjercicio) {
                    return EJERCICIOS_POR_RUTINA[i][j];
                }
            }
        }
        return "Ejercicio desconocido";
    }
}

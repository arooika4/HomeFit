package service;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Service layer: gestiona el historial de sesiones en memoria local.
 * En la versión con backend, se carga desde Back4App al arrancar
 * y se mantiene sincronizado localmente.
 *
 * RegistroSesion incluye idRegistro para actualizar notas en BBDD.
 */
public class HistorialService {

    public static class RegistroSesion {
        public final String ejercicio;
        public final String tiempo;
        public final String fecha;
        public String notas     = "";
        public int    idRegistro = 0;   // 0 = no persistido aún

        public RegistroSesion(String ejercicio, String tiempo, String fecha) {
            this.ejercicio = ejercicio;
            this.tiempo    = tiempo;
            this.fecha     = fecha;
        }
    }

    private final List<RegistroSesion> historial = new ArrayList<>();

    /** Añade un registro con el idRegistro asignado por la BBDD. */
    public void agregarRegistro(String ejercicio, String tiempo, String fecha, int idRegistro) {
        RegistroSesion rs = new RegistroSesion(ejercicio, tiempo, fecha);
        rs.idRegistro = idRegistro;
        historial.add(rs);
    }

    /** Carga masiva desde BBDD al arrancar (reemplaza cualquier dato previo). */
    public void cargarDesdeBackend(List<RegistroSesion> registros) {
        historial.clear();
        historial.addAll(registros);
    }

    public Map<String, List<RegistroSesion>> obtenerPorFecha() {
        Map<String, List<RegistroSesion>> mapa = new LinkedHashMap<>();
        for (RegistroSesion r : historial) {
            mapa.computeIfAbsent(r.fecha, k -> new ArrayList<>()).add(r);
        }
        return mapa;
    }

    public List<String> obtenerFechas() {
        return new ArrayList<>(obtenerPorFecha().keySet());
    }

    public boolean estaVacio() {
        return historial.isEmpty();
    }
}

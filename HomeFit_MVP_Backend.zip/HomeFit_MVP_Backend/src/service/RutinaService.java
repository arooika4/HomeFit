package service;

import java.util.Arrays;
import java.util.List;

/**
 * Service layer: lógica de negocio relacionada con rutinas.
 */
public class RutinaService {

    private static final String[] NOMBRES_RUTINAS = {
        "Tren superior",
        "Tren inferior",
        "Core"
    };

    /**
     * Devuelve todos los nombres de rutinas disponibles.
     */
    public List<String> obtenerNombresRutinas() {
        return Arrays.asList(NOMBRES_RUTINAS);
    }

    /**
     * Devuelve el nombre de la rutina según su índice (0-based).
     */
    public String obtenerNombreRutina(int indice) {
        if (indice < 0 || indice >= NOMBRES_RUTINAS.length) {
            throw new IllegalArgumentException("Índice de rutina no válido: " + indice);
        }
        return NOMBRES_RUTINAS[indice];
    }

    /**
     * Devuelve el número total de rutinas.
     */
    public int totalRutinas() {
        return NOMBRES_RUTINAS.length;
    }
}

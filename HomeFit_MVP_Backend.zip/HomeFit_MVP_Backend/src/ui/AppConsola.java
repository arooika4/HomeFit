package ui;

import presenter.*;
import service.*;
import view.*;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Scanner;

/**
 * AppConsola — capa UI "tonta" con backend Back4App.
 *
 * Implementa todas las interfaces View (MVP).
 * Responsabilidades:
 *   1. Mostrar datos recibidos del Presenter.
 *   2. Capturar input del usuario.
 *   3. Delegar lógica al Presenter correspondiente.
 *
 * NO contiene lógica de negocio ni de presentación.
 * La conexión con Back4App se gestiona exclusivamente en Back4AppService.
 */
public class AppConsola
        implements IMainView, IRutinaView, IEjercicioView, ICamaraView, IHistorialView {

    // ---------------------------------------------------------------- deps --
    private final Scanner scanner = new Scanner(System.in);

    // Services
    private final RutinaService     rutinaService     = new RutinaService();
    private final EjercicioService  ejercicioService  = new EjercicioService();
    private final CronometroService cronometroService = new CronometroService();
    private final HistorialService  historialService  = new HistorialService();
    private final Back4AppService   back4AppService   = new Back4AppService();

    // Presenters
    private final MainPresenter      mainPresenter;
    private final RutinaPresenter    rutinaPresenter;
    private final EjercicioPresenter ejercicioPresenter;
    private final CamaraPresenter    camaraPresenter;
    private final HistorialPresenter historialPresenter;

    // Estado de navegación mínimo (solo lo imprescindible)
    private int    indiceRutinaActual = 0;
    private String ejercicioActual    = "";

    public AppConsola() {
        mainPresenter = new MainPresenter(this, rutinaService);

        rutinaPresenter = new RutinaPresenter(
            this, rutinaService, ejercicioService, back4AppService);

        ejercicioPresenter = new EjercicioPresenter(this, ejercicioService);

        camaraPresenter = new CamaraPresenter(
            this, cronometroService, back4AppService, historialService);

        historialPresenter = new HistorialPresenter(
            this, historialService, back4AppService);
    }

    // ================================================================ INIT ==

    public void iniciar() {
        System.out.println("Cargando datos desde la base de datos...");
        back4AppService.inicializarDatos();
        List<HistorialService.RegistroSesion> historialBBDD = back4AppService.cargarHistorial();
        historialService.cargarDesdeBackend(historialBBDD);
        System.out.println("Datos cargados. Registros en historial: " + historialBBDD.size());
        pantalla1();
    }

    // ============================================================= P1: MAIN ==

    private void pantalla1() {
        mainPresenter.mostrarMenu();
        String opcion   = leerOpcion();
        int    resultado = mainPresenter.procesarOpcion(opcion);

        switch (resultado) {
            case 0: case 1: case 2:
                indiceRutinaActual = resultado;
                pantalla2();
                break;
            case -1: pantalla6(); break;
            case -2: System.exit(0); break;
            default: pantalla1(); break;
        }
    }

    @Override
    public void mostrarMenuPrincipal() {
        separador();
        System.out.println("¡Bienvenid@ a HomeFit!");
        System.out.println("  1- Tren superior [2]");
        System.out.println("  2- Tren inferior [2]");
        System.out.println("  3- Core          [2]");
        System.out.println("  4- Historial     [6]");
        System.out.println("  5- Salir");
    }

    // ============================================================ P2: RUTINA ==

    private void pantalla2() {
        rutinaPresenter.cargarRutina(indiceRutinaActual);
        String opcion    = leerOpcion();
        String resultado = rutinaPresenter.procesarOpcion(opcion);

        switch (resultado) {
            case "ATRAS": case "INICIO": pantalla1(); break;
            case "INVALIDA": pantalla2(); break;
            default:
                // Determinar índice del ejercicio seleccionado
                int indiceEj = opcion.trim().equals("1") ? 0 :
                               opcion.trim().equals("2") ? 1 : 2;
                int idEjercicio = rutinaPresenter.getIdEjercicio(indiceEj);

                ejercicioActual = resultado;
                camaraPresenter.setEjercicioActivo(idEjercicio, ejercicioActual);
                cronometroService.iniciar();
                pantalla3();
        }
    }

    @Override
    public void mostrarEjercicios(String nombreRutina, List<String> ejercicios) {
        separador();
        System.out.println(nombreRutina);
        for (int i = 0; i < ejercicios.size(); i++) {
            System.out.println("  " + (i + 1) + "- " + ejercicios.get(i) + " [3]");
        }
        System.out.println("  4- Atrás  [1]");
        System.out.println("  5- Inicio [1]");
    }

    // ========================================================== P3: EJERCICIO ==

    private void pantalla3() {
        ejercicioPresenter.cargarEjercicio(ejercicioActual);
        String opcion    = leerOpcion();
        String resultado = ejercicioPresenter.procesarOpcion(opcion);

        switch (resultado) {
            case "VIDEO":  pantalla3(); break;
            case "CAMARA": pantalla4(); break;
            case "ATRAS":  pantalla2(); break;
            case "INICIO": pantalla1(); break;
            default:       pantalla3(); break;
        }
    }

    @Override
    public void mostrarDetalleEjercicio(String nombreEjercicio, String descripcion) {
        separador();
        System.out.println(nombreEjercicio);
        System.out.println("  1- Video explicativo del ejercicio [Video]");
        System.out.println();
        System.out.println(descripcion);
        System.out.println();
        System.out.println("  2- Sacar foto del ejercicio [4]");
        System.out.println("  3- Atrás  [2]");
        System.out.println("  4- Inicio [1]");
    }

    @Override
    public void mostrarVideoSimulado(String nombreEjercicio) {
        System.out.println("  [Reproduciendo video de " + nombreEjercicio + "]");
    }

    // ============================================================ P4: CAMARA ==

    private void pantalla4() {
        camaraPresenter.mostrarCamara();
        String opcion    = leerOpcion();
        String resultado = camaraPresenter.procesarOpcionCamara(opcion);

        switch (resultado) {
            case "FOTO":   pantalla5(); break;
            case "ATRAS":  pantalla3(); break;
            default:       pantalla4(); break;
        }
    }

    @Override
    public void mostrarPantallaCamara() {
        separador();
        System.out.println("Cámara");
        System.out.println("  1- Sacar foto [5]");
        System.out.println("  2- Salir      [3]");
    }

    // ========================================================= P5: FOTO HECHA ==

    private void pantalla5() {
        // La view ya fue actualizada por mostrarFotoRealizada desde el presenter
        String opcion   = leerOpcion();
        String fechaHoy = LocalDate.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
        String resultado = camaraPresenter.procesarOpcionFoto(opcion, fechaHoy);

        switch (resultado) {
            case "REPETIR":  pantalla4(); break;
            case "TERMINAR": pantalla1(); break;
            default:         pantalla5(); break;
        }
    }

    @Override
    public void mostrarFotoRealizada(String tiempoFormateado) {
        separador();
        System.out.println("Foto realizada");
        System.out.println("  [Foto/Video referencia]");
        System.out.println("  [Foto realizada]");
        System.out.println();
        System.out.println("  Tiempo del ejercicio: " + tiempoFormateado);
        System.out.println();
        System.out.println("  1- Volver a sacar foto [4]");
        System.out.println("  2- Terminar ejercicio  [1]");
    }

    // ========================================================= P6: HISTORIAL ==

    private void pantalla6() {
        historialPresenter.mostrarHistorial();
        String opcion    = leerOpcion();
        String resultado = historialPresenter.procesarOpcionHistorial(opcion);

        if (resultado.startsWith("DETALLE_")) {
            pantalla7();
        } else if (resultado.equals("ATRAS") || resultado.equals("INICIO")) {
            pantalla1();
        } else {
            pantalla6();
        }
    }

    @Override
    public void mostrarHistorial(List<String> fechas) {
        separador();
        System.out.println("Historial");
        if (fechas.isEmpty()) {
            System.out.println("  (Sin registros)");
        } else {
            for (int i = 0; i < fechas.size(); i++) {
                System.out.println("  " + (i + 1) + "- " + fechas.get(i) + " [7]");
            }
        }
        int opAtras  = fechas.size() + 1;
        int opInicio = fechas.size() + 2;
        System.out.println("  " + opAtras  + "- Atrás  [1]");
        System.out.println("  " + opInicio + "- Inicio [1]");
    }

    // ====================================================== P7: HISTORIAL DET ==

    private void pantalla7() {
        historialPresenter.mostrarDetalle();
        int totalFotos = historialPresenter.contarFotosEnDetalle();
        System.out.println();
        System.out.println("  " + (totalFotos + 1) + "- Atrás  [6]");
        System.out.println("  " + (totalFotos + 2) + "- Inicio [1]");

        String opcion    = leerOpcion();
        String resultado = historialPresenter.procesarOpcionDetalle(opcion, totalFotos);

        if (resultado.startsWith("FOTO_")) {
            pantalla8();
        } else if (resultado.equals("ATRAS")) {
            pantalla6();
        } else if (resultado.equals("INICIO")) {
            pantalla1();
        } else {
            pantalla7();
        }
    }

    @Override
    public void mostrarDetalleSesion(String fecha, List<String[]> registros) {
        separador();
        System.out.println("Historial detalle");
        System.out.println();
        System.out.println("  " + fecha);
        for (String[] r : registros) {
            // r = [ejercicio, tiempo, notas, numeroFoto]
            System.out.println("  * " + r[0] + ":");
            System.out.println("     * Tiempo: " + r[1]);
            if (!r[2].isEmpty()) System.out.println("     * Notas: " + r[2]);
            System.out.println("     * " + r[3] + "- [Foto realizada] [8]");
        }
    }

    // ====================================================== P8: FOTO AMPLIADA ==

    private void pantalla8() {
        // La view ya fue actualizada por mostrarFotoAmpliada desde el presenter
        System.out.println();
        System.out.println("  2- Atrás  [7]");
        System.out.println("  3- Inicio [1]");

        String opcion    = leerOpcion();
        String notaNueva = null;

        if (opcion.trim().equals("1")) {
            System.out.print("  Escribe la nota: ");
            notaNueva = scanner.nextLine().trim();
        }

        String resultado = historialPresenter.procesarOpcionFotoAmpliada(opcion, notaNueva);

        switch (resultado) {
            case "NOTA_GUARDADA": pantalla8(); break;
            case "ATRAS":         pantalla7(); break;
            case "INICIO":        pantalla1(); break;
            default:              pantalla8(); break;
        }
    }

    @Override
    public void mostrarFotoAmpliada(String ejercicio, String tiempo, String notas) {
        separador();
        System.out.println("Foto ampliada");
        System.out.println("  [Foto referencia]");
        System.out.println("  [Foto realizada]");
        System.out.println("  1- Notas: " + notas);
        System.out.println();
    }

    // ===================================================== Mensajes de error ==

    @Override
    public void mostrarMensajeError(String mensaje) {
        System.out.println(mensaje);
    }

    // ================================================================ util ==

    private void separador() {
        System.out.println();
        System.out.println("-----------------------------------------------");
    }

    private String leerOpcion() {
        System.out.print("> [Escribir opción]: ");
        return scanner.nextLine().trim();
    }
}

package view;

/**
 * Interfaz de las pantallas de cámara y foto (Pantallas 4 y 5).
 */
public interface ICamaraView {
    void mostrarPantallaCamara();
    void mostrarFotoRealizada(String tiempoFormateado);
    void mostrarMensajeError(String mensaje);
}

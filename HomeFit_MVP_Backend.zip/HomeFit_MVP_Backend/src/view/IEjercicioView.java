package view;

/**
 * Interfaz de la pantalla de ejercicio (Pantalla 3).
 */
public interface IEjercicioView {
    void mostrarDetalleEjercicio(String nombreEjercicio, String descripcion);
    void mostrarVideoSimulado(String nombreEjercicio);
    void mostrarMensajeError(String mensaje);
}

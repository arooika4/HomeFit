package view;

import java.util.List;
import java.util.Map;

/**
 * Interfaz de las pantallas de historial (Pantallas 6, 7 y 8).
 */
public interface IHistorialView {
    void mostrarHistorial(List<String> fechas);
    void mostrarDetalleSesion(String fecha, List<String[]> registros);
    void mostrarFotoAmpliada(String ejercicio, String tiempo, String notas);
    void mostrarMensajeError(String mensaje);
}

package view;

/**
 * Interfaz de la pantalla principal (Pantalla 1).
 * Solo muestra datos y captura input. Sin lógica de negocio.
 */
public interface IMainView {
    void mostrarMenuPrincipal();
    void mostrarMensajeError(String mensaje);
}

package view;

import java.util.List;

/**
 * Interfaz de la pantalla de rutina (Pantalla 2).
 */
public interface IRutinaView {
    void mostrarEjercicios(String nombreRutina, List<String> ejercicios);
    void mostrarMensajeError(String mensaje);
}

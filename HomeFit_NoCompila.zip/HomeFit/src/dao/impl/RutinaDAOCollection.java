package dao.impl;

import dao.RutinaDAO;
import model.Rutina;
import java.util.ArrayList;
import java.util.List;

public class RutinaDAOCollection implements RutinaDAO {

    private List<Rutina> rutinas = new ArrayList<>();

    @Override
    public void crear(Rutina rutina) {
        rutinas.add(rutina);
    }

    @Override
    public Rutina obtener(int id) {
        for (Rutina r : rutinas) {
            if (r.getIdRutina() == id) {
                return r;
            }
        }
        return null;
    }

    @Override
    public List<Rutina> obtenerTodas() {
        return rutinas;
    }

    @Override
    public void actualizar(Rutina rutina) {
        for (int i = 0; i < rutinas.size(); i++) {
            if (rutinas.get(i).getIdRutina() == rutina.getIdRutina()) {
                rutinas.set(i, rutina);
                break;
            }
        }
    }

    @Override
    public void eliminar(int id) {
        rutinas.removeIf(r -> r.getIdRutina() == id);
    }
}

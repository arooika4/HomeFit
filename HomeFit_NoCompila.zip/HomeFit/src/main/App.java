package main;

import ui.AppConsola;

public class App {

    public static void main(String[] args) {
        AppConsola app = new AppConsola();
        app.iniciar();
    }
}

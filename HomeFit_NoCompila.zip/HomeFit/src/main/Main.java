package main;

import dao.impl.parse.RutinaDAOParse;
import dao.impl.parse.EjercicioDAOParse;
import dao.impl.parse.SesionDAOParse;
import dao.impl.parse.RegistroEjercicioDAOParse;
import model.Rutina;
import model.Ejercicio;
import model.Sesion;
import model.RegistroEjercicio;

import java.time.LocalDate;
import java.util.List;

public class Main {

    public static void main(String[] args) {

        RutinaDAOParse rutinaDAO                   = new RutinaDAOParse();
        EjercicioDAOParse ejercicioDAO             = new EjercicioDAOParse();
        SesionDAOParse sesionDAO                   = new SesionDAOParse();
        RegistroEjercicioDAOParse registroDAO      = new RegistroEjercicioDAOParse();

        System.out.println("\n========== PRUEBA RUTINA ==========");
        Rutina r = new Rutina(10, "Tren superior");
        rutinaDAO.crear(r);

        List<Rutina> rutinas = rutinaDAO.obtenerTodas();
        System.out.println("Rutinas en BBDD: " + rutinas.size());
        for (Rutina rutina : rutinas) {
            System.out.println("  - " + rutina.getNombre());
        }

        r.setNombre("Tren superior (actualizado)");
        rutinaDAO.actualizar(r);

        rutinaDAO.eliminar(10);

        System.out.println("\n========== PRUEBA EJERCICIO ==========");
        Ejercicio e = new Ejercicio(10, "Push up");
        e.setDescripcion("Flexiones de brazos");
        e.setVideoReferencia("https://video.com/pushup");
        e.setIdRutina(1);
        ejercicioDAO.crear(e);

        List<Ejercicio> ejercicios = ejercicioDAO.obtenerTodos();
        System.out.println("Ejercicios en BBDD: " + ejercicios.size());
        for (Ejercicio ej : ejercicios) {
            System.out.println("  - " + ej.getNombre());
        }

        e.setNombre("Push up (actualizado)");
        ejercicioDAO.actualizar(e);

        ejercicioDAO.eliminar(10);

        System.out.println("\n========== PRUEBA SESION ==========");
        Sesion s = new Sesion(10, LocalDate.now());
        sesionDAO.crear(s);

        List<Sesion> sesiones = sesionDAO.obtenerTodas();
        System.out.println("Sesiones en BBDD: " + sesiones.size());
        for (Sesion sesion : sesiones) {
            System.out.println("  - " + sesion.getFecha());
        }

        s.setFecha(LocalDate.of(2026, 1, 1));
        sesionDAO.actualizar(s);

        sesionDAO.eliminar(10);

        System.out.println("\n========== PRUEBA REGISTRO EJERCICIO ==========");
        RegistroEjercicio reg = new RegistroEjercicio();
        reg.setIdRegistro(10);
        reg.setTiempo(120);
        reg.setFoto("https://foto.com/foto1.jpg");
        reg.setIdSesion(1);
        reg.setIdEjercicio(1);
        registroDAO.crear(reg);

        List<RegistroEjercicio> registros = registroDAO.obtenerTodos();
        System.out.println("Registros en BBDD: " + registros.size());
        for (RegistroEjercicio registro : registros) {
            System.out.println("  - Tiempo: " + registro.getTiempo() + "s");
        }

        registroDAO.actualizar(reg);

        registroDAO.eliminar(10);

        System.out.println("\n========== FIN DE PRUEBAS ==========");
    }
}

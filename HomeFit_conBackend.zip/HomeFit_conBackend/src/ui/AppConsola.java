package ui;

import dao.impl.parse.EjercicioDAOParse;
import dao.impl.parse.RegistroEjercicioDAOParse;
import dao.impl.parse.RutinaDAOParse;
import dao.impl.parse.SesionDAOParse;
import model.Ejercicio;
import model.RegistroEjercicio;
import model.Rutina;
import model.Sesion;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class AppConsola {
    Scanner scanner = new Scanner(System.in);

    private final RutinaDAOParse rutinaDAO = new RutinaDAOParse();
    private final EjercicioDAOParse ejercicioDAO = new EjercicioDAOParse();
    private final SesionDAOParse sesionDAO = new SesionDAOParse();
    private final RegistroEjercicioDAOParse registroDAO = new RegistroEjercicioDAOParse();

    private String rutinaSeleccionada = "";
    private int idRutinaSeleccionada = -1;
    private String ejercicioSeleccionado = "";
    private int idEjercicioSeleccionado = -1;

    private Sesion sesionActiva = null;  

    private long tiempoInicioMs = 0;
    private long tiempoTranscurridoMs = 0;

    // id_rutina:   1=Tren superior     2=Tren inferior     3=Core
    private static final int[] IDS_RUTINA = {1, 2, 3};
    private static final String[] NOMBRES_RUTINA = {"Tren superior", "Tren inferior", "Core"};

    // id_ejercicio:    1-3 tren superior   4-6 tren inferior   7-9 core
    private static final int[][] IDS_EJERCICIO = {
        {1, 2, 3},
        {4, 5, 6},
        {7, 8, 9}
    };
    private static final String[][] EJERCICIOS_POR_RUTINA = {
        {"Push up tradicional", "Vuelo lateral", "Fondos de tríceps"},
        {"Sentadilla con peso corporal", "Estocada búlgara", "Puente de glúteo"},
        {"Bicicleta abdominal", "Crunch abdominal", "Plancha"}
    };
    private int indiceRutina = 0;

    private static class RegistroSesion {
        String ejercicio;
        String tiempo;      
        String fecha;
        String notas = "";
        int idRegistro;
        RegistroSesion(String ejercicio, String tiempo, String fecha, int idRegistro) {
            this.ejercicio = ejercicio;
            this.tiempo = tiempo;
            this.fecha = fecha;
            this.idRegistro = idRegistro;
        }
    }
    private final List<RegistroSesion> historial = new ArrayList<>();
    private int indiceSesionDetalle = 0;
    private int proximoIdSesion = 1;
    private int proximoIdRegistro = 1;

    // INICIO
    public void iniciar() {
        System.out.println("Cargando datos desde la base de datos...");
        cargarDatosIniciales();
        pantalla1();
    }

    
    private void cargarDatosIniciales() {
        // Asegurarse de que el nombre de las rutinas existen en BBDD
        List<Rutina> rutinasEnBBDD = rutinaDAO.obtenerTodas();
        for (int i = 0; i < IDS_RUTINA.length; i++) {
            final String nombre = NOMBRES_RUTINA[i];
            boolean existe = rutinasEnBBDD.stream()
                .anyMatch(r -> nombre.equals(r.getNombre()));
            if (!existe) {
                rutinaDAO.crear(new Rutina(IDS_RUTINA[i], nombre));
            }
        }

        // Asegurarse de que el nombre de los ejercicios existen en BBDD
        List<Ejercicio> ejerciciosEnBBDD = ejercicioDAO.obtenerTodos();
        for (int i = 0; i < IDS_EJERCICIO.length; i++) {
            for (int j = 0; j < IDS_EJERCICIO[i].length; j++) {
                final String nombreEj = EJERCICIOS_POR_RUTINA[i][j];
                boolean existe = ejerciciosEnBBDD.stream()
                    .anyMatch(e -> nombreEj.equals(e.getNombre()));
                if (!existe) {
                    Ejercicio e = new Ejercicio(IDS_EJERCICIO[i][j], nombreEj);
                    e.setIdRutina(IDS_RUTINA[i]);
                    ejercicioDAO.crear(e);
                }
            }
        }

        // Cargar historial desde BBDD
        historial.clear();
        List<Sesion> sesiones  = sesionDAO.obtenerTodas();
        List<RegistroEjercicio> registros = registroDAO.obtenerTodos();
        List<Ejercicio> ejercicios = ejercicioDAO.obtenerTodos();

        for (Sesion s : sesiones) {
            if (s.getIdSesion() >= proximoIdSesion) proximoIdSesion = s.getIdSesion() + 1;
        }
        for (RegistroEjercicio reg : registros) {
            if (reg.getIdRegistro() >= proximoIdRegistro) proximoIdRegistro = reg.getIdRegistro() + 1;
        }

        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        for (RegistroEjercicio reg : registros) {
            Sesion sesion = sesiones.stream()
                .filter(s -> s.getIdSesion() == reg.getIdSesion())
                .findFirst().orElse(null);
            
            Ejercicio ej = ejercicios.stream()
                .filter(e -> e.getIdEjercicio() == reg.getIdEjercicio())
                .findFirst().orElse(null);
            String nombreEj = (ej != null && ej.getNombre() != null && !ej.getNombre().isEmpty())
                ? ej.getNombre()
                : buscarNombreEjercicioLocal(reg.getIdEjercicio());

            String fecha = (sesion != null && sesion.getFecha() != null)
                ? sesion.getFecha().format(fmt)
                : "Sin fecha";
            String tiempo = formatearTiempo((long) reg.getTiempo() * 1000L);

            String notasCargadas = (reg.getNotas() != null) ? reg.getNotas() : "";
            RegistroSesion rs = new RegistroSesion(nombreEj, tiempo, fecha, reg.getIdRegistro());
            rs.notas = notasCargadas;
            historial.add(rs);
        }

        System.out.println("Datos cargados. Registros en historial: " + historial.size());
    }

    // HELPERS
    private void iniciarCronometro() {
        tiempoInicioMs = System.currentTimeMillis();
    }

    private void detenerCronometro() {
        tiempoTranscurridoMs = System.currentTimeMillis() - tiempoInicioMs;
    }

    private String formatearTiempo(long ms) {
        long totalSeg = ms / 1000;
        long horas = totalSeg / 3600;
        long minutos = (totalSeg % 3600) / 60;
        long segundos = totalSeg % 60;
        return String.format("%02d:%02d:%02d", horas, minutos, segundos);
    }

    private Map<String, List<RegistroSesion>> historialPorFecha() {
        Map<String, List<RegistroSesion>> mapa = new LinkedHashMap<>();
        for (RegistroSesion r : historial) {
            mapa.computeIfAbsent(r.fecha, k -> new ArrayList<>()).add(r);
        }
        return mapa;
    }

    private String buscarNombreEjercicioLocal(int idEjercicio) {
        for (int i = 0; i < IDS_EJERCICIO.length; i++) {
            for (int j = 0; j < IDS_EJERCICIO[i].length; j++) {
                if (IDS_EJERCICIO[i][j] == idEjercicio) {
                    return EJERCICIOS_POR_RUTINA[i][j];
                }
            }
        }
        return "Ejercicio desconocido";
    }

    private int guardarEnBBDD(int idEjercicio, int idRutina, long tiempoMs, String notas) {
        // Crear sesión con la fecha de hoy
        int idSesion = proximoIdSesion++;
        sesionActiva = new Sesion(idSesion, LocalDate.now());
        sesionDAO.crear(sesionActiva);

        // Crear registro de ejercicio con notas
        int idRegistro = proximoIdRegistro++;
        RegistroEjercicio reg = new RegistroEjercicio();
        reg.setIdRegistro(idRegistro);
        reg.setIdSesion(idSesion);
        reg.setIdEjercicio(idEjercicio);
        reg.setTiempo((int)(tiempoMs / 1000));
        reg.setFoto("");
        reg.setNotas(notas);
        registroDAO.crear(reg);

        return idRegistro;
    }

    // DESCRIPCIONES EJERCICIOS
    private void mostrarDescripcionEjercicio() {
        switch (ejercicioSeleccionado) {

            case "Push up tradicional":
                System.out.println("  CONSEJOS:");
                System.out.println("  • Intenta que tus codos queden ligeramente por debajo de la línea de tus hombros.");
                System.out.println("  • Baja en un solo bloque, manteniendo el abdomen contraído y evitando");
                System.out.println("    que tu columna se deforme.");
                System.out.println();
                System.out.println("  Las flexiones son un ejercicio multiarticular que involucra principalmente");
                System.out.println("  pecho, hombros y tríceps, al tiempo que requiere activación constante del");
                System.out.println("  core para mantener la alineación corporal.");
                System.out.println();
                System.out.println("  Dificultad (3 series):");
                System.out.println("  • Novato: 8 repeticiones");
                System.out.println("  • Intermedio: 15 repeticiones");
                System.out.println("  • Avanzado: 25+ repeticiones");
                break;

            case "Vuelo lateral":
                System.out.println("  CONSEJOS:");
                System.out.println("  • Puedes usar cualquier objeto con peso: botellas, paquetes de arroz, etc.");
                System.out.println("  • Mantén los hombros hacia abajo y los codos ligeramente extendidos.");
                System.out.println();
                System.out.println("  El vuelo lateral fortalece el deltoides medio, responsable de la elevación");
                System.out.println("  lateral del brazo.");
                System.out.println();
                System.out.println("  Dificultad (3 series):");
                System.out.println("  • Novato: 10 repeticiones");
                System.out.println("  • Intermedio: 15 repeticiones");
                System.out.println("  • Avanzado: 20+ repeticiones");
                break;

            case "Fondos de tríceps":
                System.out.println("  CONSEJOS:");
                System.out.println("  • Concéntrate en que el movimiento provenga desde los codos.");
                System.out.println("  • Junta tus escápulas durante el ejercicio y mantén la postura.");
                System.out.println();
                System.out.println("  Los fondos de tríceps fortalecen el tríceps braquial.");
                System.out.println();
                System.out.println("  Dificultad (3 series):");
                System.out.println("  • Novato: 8 repeticiones");
                System.out.println("  • Intermedio: 15 repeticiones");
                System.out.println("  • Avanzado: 20+ repeticiones");
                break;

            case "Sentadilla con peso corporal":
                System.out.println("  CONSEJOS:");
                System.out.println("  • Desciende de forma controlada, evitando que tus rodillas se junten.");
                System.out.println("  • Intenta mantener alineadas tus rodillas con la punta de tus pies.");
                System.out.println();
                System.out.println("  La sentadilla activa simultáneamente cuádriceps, glúteos e isquiotibiales.");
                System.out.println();
                System.out.println("  Dificultad (3 series):");
                System.out.println("  • Novato: 10 repeticiones");
                System.out.println("  • Intermedio: 20 repeticiones");
                System.out.println("  • Avanzado: 30+ repeticiones");
                break;

            case "Estocada búlgara":
                System.out.println("  CONSEJOS:");
                System.out.println("  • Pie delantero más adelantado: más dominante de cadera.");
                System.out.println("  • Pie delantero más atrás: más dominante de rodilla.");
                System.out.println();
                System.out.println("  Ejercicio unilateral que trabaja intensamente cuádriceps y glúteos.");
                System.out.println();
                System.out.println("  Dificultad (3 series):");
                System.out.println("  • Novato: 8 repeticiones por pierna");
                System.out.println("  • Intermedio: 12 repeticiones por pierna");
                System.out.println("  • Avanzado: 16+ repeticiones por pierna");
                break;

            case "Puente de glúteo":
                System.out.println("  CONSEJOS:");
                System.out.println("  • Pies adelantados: mayor tensión en isquiotibiales.");
                System.out.println("  • Empuja con los talones y contrae fuertemente los glúteos.");
                System.out.println();
                System.out.println("  Fortalece el glúteo mayor y los isquiotibiales.");
                System.out.println();
                System.out.println("  Dificultad (3 series):");
                System.out.println("  • Novato: 12 repeticiones");
                System.out.println("  • Intermedio: 20 repeticiones");
                System.out.println("  • Avanzado: 30+ repeticiones");
                break;

            case "Bicicleta abdominal":
                System.out.println("  CONSEJOS:");
                System.out.println("  • Mantén la zona lumbar pegada al suelo durante todo el movimiento.");
                System.out.println("  • Realiza el movimiento de forma controlada, sin tirar del cuello.");
                System.out.println();
                System.out.println("  Combina flexión de tronco con rotación, activando recto abdominal y oblicuos.");
                System.out.println();
                System.out.println("  Dificultad (3 series):");
                System.out.println("  • Novato: 20 repeticiones");
                System.out.println("  • Intermedio: 40 repeticiones");
                System.out.println("  • Avanzado: 60+ repeticiones");
                break;

            case "Crunch abdominal":
                System.out.println("  CONSEJOS:");
                System.out.println("  • Eleva ligeramente los hombros del suelo contrayendo el abdomen.");
                System.out.println("  • Mantén la zona lumbar apoyada y evita impulsarte con el cuello.");
                System.out.println();
                System.out.println("  Ejercicio clásico para fortalecer el recto abdominal.");
                System.out.println();
                System.out.println("  Dificultad (3 series):");
                System.out.println("  • Novato: 15 repeticiones");
                System.out.println("  • Intermedio: 30 repeticiones");
                System.out.println("  • Avanzado: 50+ repeticiones");
                break;

            case "Plancha":
                System.out.println("  CONSEJOS:");
                System.out.println("  • Coloca los antebrazos debajo de los hombros y mantén el cuerpo en línea recta.");
                System.out.println("  • Activa el abdomen y los glúteos para evitar que la cadera se hunda.");
                System.out.println();
                System.out.println("  Activa simultáneamente transverso abdominal, oblicuos y musculatura lumbar.");
                System.out.println();
                System.out.println("  Dificultad (3 series):");
                System.out.println("  • Novato: 20 segundos");
                System.out.println("  • Intermedio: 1 minuto");
                System.out.println("  • Avanzado: 2+ minutos");
                break;

            default:
                System.out.println("  (Descripción no disponible)");
        }
    }

    // PANTALLAS

    // PANTALLA 1: INICIO
    private void pantalla1() {
        System.out.println();
        System.out.println("-----------------------------------------------");
        System.out.println("¡Bienvenid@ a HomeFit!");
        System.out.println("  1- Tren superior [2]");
        System.out.println("  2- Tren inferior [2]");
        System.out.println("  3- Core          [2]");
        System.out.println("  4- Historial     [6]");
        System.out.println("  5- Salir");
        System.out.print("> [Escribir opción]: ");

        String opcion = scanner.nextLine().trim();

        switch (opcion) {
            case "1":
                rutinaSeleccionada = "Tren superior";
                idRutinaSeleccionada = IDS_RUTINA[0];
                indiceRutina = 0;
                pantalla2();
                break;
            case "2":
                rutinaSeleccionada = "Tren inferior";
                idRutinaSeleccionada = IDS_RUTINA[1];
                indiceRutina = 1;
                pantalla2();
                break;
            case "3":
                rutinaSeleccionada = "Core";
                idRutinaSeleccionada = IDS_RUTINA[2];
                indiceRutina = 2;
                pantalla2();
                break;
            case "4":
                pantalla6();
                break;
            case "5":
                System.exit(0);
            default:
                System.out.println("[Opción no reconocida]");
                pantalla1();
        }
    }

    // PANTALLA 2: RUTINA
    private void pantalla2() {
        String[] ejercicios = EJERCICIOS_POR_RUTINA[indiceRutina];
        System.out.println();
        System.out.println("-----------------------------------------------");
        System.out.println(rutinaSeleccionada);
        System.out.println("  1- " + ejercicios[0] + " [3]");
        System.out.println("  2- " + ejercicios[1] + " [3]");
        System.out.println("  3- " + ejercicios[2] + " [3]");
        System.out.println("  4- Atrás  [1]");
        System.out.println("  5- Inicio [1]");
        System.out.print("> [Escribir opción]: ");

        String opcion = scanner.nextLine().trim();

        switch (opcion) {
            case "1":
                ejercicioSeleccionado = ejercicios[0];
                idEjercicioSeleccionado = IDS_EJERCICIO[indiceRutina][0];
                iniciarCronometro();
                pantalla3();
                break;
            case "2":
                ejercicioSeleccionado = ejercicios[1];
                idEjercicioSeleccionado = IDS_EJERCICIO[indiceRutina][1];
                iniciarCronometro();
                pantalla3();
                break;
            case "3":
                ejercicioSeleccionado = ejercicios[2];
                idEjercicioSeleccionado = IDS_EJERCICIO[indiceRutina][2];
                iniciarCronometro();
                pantalla3();
                break;
            case "4":
                pantalla1();
                break;
            case "5":
                pantalla1();
                break;
            default:
                System.out.println("[Opción no reconocida]");
                pantalla2();
        }
    }

    // PANTALLA 3: EJERCICIO
    private void pantalla3() {
        System.out.println();
        System.out.println("-----------------------------------------------");
        System.out.println(ejercicioSeleccionado);
        System.out.println("  1- Video explicativo del ejercicio [Video]");
        System.out.println();
        mostrarDescripcionEjercicio();
        System.out.println();
        System.out.println("  2- Sacar foto del ejercicio [4]");
        System.out.println("  3- Atrás  [2]");
        System.out.println("  4- Inicio [1]");
        System.out.print("> [Escribir opción]: ");

        String opcion = scanner.nextLine().trim();

        switch (opcion) {
            case "1":
                System.out.println("  [Reproduciendo video de " + ejercicioSeleccionado + "]");
                pantalla3();
                break;
            case "2":
                pantalla4();
                break;
            case "3":
                pantalla2();
                break;
            case "4":
                pantalla1();
                break;
            default:
                System.out.println("[Opción no reconocida]");
                pantalla3();
        }
    }

    // PANTALLA 4: CÁMARA
    private void pantalla4() {
        System.out.println();
        System.out.println("-----------------------------------------------");
        System.out.println("Cámara");
        System.out.println("  1- Sacar foto [5]");
        System.out.println("  2- Salir      [3]");
        System.out.print("> [Escribir opción]: ");

        String opcion = scanner.nextLine().trim();

        switch (opcion) {
            case "1":
                detenerCronometro();
                pantalla5();
                break;
            case "2":
                pantalla3();
                break;
            default:
                System.out.println("[Opción no reconocida]");
                pantalla4();
        }
    }

    // PANTALLA 5: FOTO REALIZADA
    private void pantalla5() {
        String tiempoFormateado = formatearTiempo(tiempoTranscurridoMs);
        String fechaHoy = LocalDate.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

        System.out.println();
        System.out.println("-----------------------------------------------");
        System.out.println("Foto realizada");
        System.out.println("  [Foto/Video referencia]");
        System.out.println("  [Foto realizada]");
        System.out.println();
        System.out.println("  Tiempo del ejercicio: " + tiempoFormateado);
        System.out.println();
        System.out.println("  1- Volver a sacar foto [4]");
        System.out.println("  2- Terminar ejercicio  [1]");
        System.out.print("> [Escribir opción]: ");

        String opcion = scanner.nextLine().trim();

        switch (opcion) {
            case "1":
                iniciarCronometro();
                pantalla4();
                break;
            case "2":
                // Guardar en back4app
                System.out.println("  Guardando en la base de datos...");
                int idRegistro = guardarEnBBDD(
                    idEjercicioSeleccionado,
                    idRutinaSeleccionada,
                    tiempoTranscurridoMs,
                    ""
                );
                // Añadir al historial local
                historial.add(new RegistroSesion(
                    ejercicioSeleccionado,
                    tiempoFormateado,
                    fechaHoy,
                    idRegistro
                ));
                System.out.println("  Ejercicio guardado correctamente");
                pantalla1();
                break;
            default:
                System.out.println("[Opción no reconocida]");
                pantalla5();
        }
    }

    // PANTALLA 6: HISTORIAL
    private void pantalla6() {
        Map<String, List<RegistroSesion>> porFecha = historialPorFecha();
        List<String> fechas = new ArrayList<>(porFecha.keySet());

        System.out.println();
        System.out.println("-----------------------------------------------");
        System.out.println("Historial");

        if (fechas.isEmpty()) {
            System.out.println("  (Sin registros)");
        } else {
            for (int i = 0; i < fechas.size(); i++) {
                System.out.println("  " + (i + 1) + "- " + fechas.get(i) + " [7]");
            }
        }

        int opcionAtras = fechas.size() + 1;
        int opcionInicio = fechas.size() + 2;
        System.out.println("  " + opcionAtras  + "- Atrás  [1]");
        System.out.println("  " + opcionInicio + "- Inicio [1]");
        System.out.print("> [Escribir opción]: ");

        String opcion = scanner.nextLine().trim();
        int num = -1;
        try { num = Integer.parseInt(opcion); } catch (NumberFormatException ignored) {}

        if (num >= 1 && num <= fechas.size()) {
            indiceSesionDetalle = num - 1;
            pantalla7(porFecha, fechas);
        } else if (num == opcionAtras || num == opcionInicio) {
            pantalla1();
        } else {
            System.out.println("[Opción no reconocida]");
            pantalla6();
        }
    }

    // PANTALLA 7: HISTORIAL DETALLE
    private void pantalla7(Map<String, List<RegistroSesion>> porFecha, List<String> fechas) {
        System.out.println();
        System.out.println("-----------------------------------------------");
        System.out.println("Historial detalle");

        List<RegistroSesion> registrosVisibles = new ArrayList<>();
        int contadorFoto = 1;
        for (int f = indiceSesionDetalle; f < Math.min(indiceSesionDetalle + 2, fechas.size()); f++) {
            String fecha = fechas.get(f);
            System.out.println();
            System.out.println("  " + fecha);
            for (RegistroSesion r : porFecha.get(fecha)) {
                registrosVisibles.add(r);
                System.out.println("  * " + r.ejercicio + ":");
                System.out.println("     * Tiempo: " + r.tiempo);
                if (!r.notas.isEmpty()) System.out.println("     * Notas: " + r.notas);
                System.out.println("     * " + contadorFoto + "- [Foto realizada] [8]");
                contadorFoto++;
            }
        }

        System.out.println();
        System.out.println("  " + contadorFoto       + "- Atrás  [6]");
        System.out.println("  " + (contadorFoto + 1) + "- Inicio [1]");
        System.out.print("> [Escribir opción]: ");

        String opcion = scanner.nextLine().trim();
        int num = -1;
        try { 
            num = Integer.parseInt(opcion); 
        } catch (NumberFormatException ignored) {}

        if (num >= 1 && num < contadorFoto) {
            pantalla8(registrosVisibles.get(num - 1));
        } else if (num == contadorFoto) {
            pantalla6();
        } else if (num == contadorFoto + 1) {
            pantalla1();
        } else {
            System.out.println("[Opción no reconocida]");
            pantalla7(porFecha, fechas);
        }
    }

    // PANTALLA 8: FOTO AMPLIADA
    private void pantalla8(RegistroSesion registro) {
        System.out.println();
        System.out.println("-----------------------------------------------");
        System.out.println("Foto ampliada");
        System.out.println("  [Foto referencia]");
        System.out.println("  [Foto realizada]");
        System.out.println("  1- Notas: " + registro.notas);
        System.out.println();
        System.out.println("  2- Atrás  [7]");
        System.out.println("  3- Inicio [1]");
        System.out.print("> [Escribir opción]: ");

        String opcion = scanner.nextLine().trim();

        switch (opcion) {
            case "1":
                System.out.print("  Escribe la nota: ");
                registro.notas = scanner.nextLine().trim();
                actualizarNotasEnBBDD(registro.idRegistro, registro.notas);
                pantalla8(registro);
                break;
            case "2":
                Map<String, List<RegistroSesion>> porFecha = historialPorFecha();
                List<String> fechas = new ArrayList<>(porFecha.keySet());
                pantalla7(porFecha, fechas);
                break;
            case "3":
                pantalla1();
                break;
            default:
                System.out.println("[Opción no reconocida]");
                pantalla8(registro);
        }
    }

    private void actualizarNotasEnBBDD(int idRegistro, String notas) {
        if (idRegistro <= 0) return;
        try {
            RegistroEjercicio reg = registroDAO.obtener(idRegistro);
            if (reg == null) return;
            reg.setNotas(notas);
            registroDAO.actualizar(reg);
        } catch (Exception e) {
            System.out.println("[ERROR] No se pudo guardar la nota: " + e.getMessage());
        }
    }
}
# HomeFit — Sin Backend (MVP)

Aplicación de consola para gestionar rutinas de ejercicio en casa.
Arquitectura **Model-View-Presenter (MVP)** sin backend (datos en memoria).

---

## 📁 Estructura de paquetes

```
HomeFit/
└── src/
    ├── model/                      # Entidades de dominio
    │   ├── Ejercicio.java
    │   ├── Rutina.java
    │   ├── Sesion.java
    │   └── RegistroEjercicio.java
    │
    ├── dao/                        # Interfaces de acceso a datos
    │   ├── EjercicioDAO.java
    │   ├── RutinaDAO.java
    │   ├── SesionDAO.java
    │   └── RegistroEjercicioDAO.java
    │   └── impl/                   # Implementaciones en memoria (Collection)
    │       ├── EjercicioDAOCollection.java
    │       ├── RutinaDAOCollection.java
    │       ├── SesionDAOCollection.java
    │       └── RegistroEjercicioDAOCollection.java
    │
    ├── service/                    # Lógica de negocio
    │   ├── RutinaService.java
    │   ├── EjercicioService.java
    │   ├── CronometroService.java
    │   └── HistorialService.java
    │
    ├── view/                       # Interfaces de View (contrato MVP)
    │   ├── IMainView.java
    │   ├── IRutinaView.java
    │   ├── IEjercicioView.java
    │   ├── ICamaraView.java
    │   └── IHistorialView.java
    │
    ├── presenter/                  # Presenters (lógica de presentación)
    │   ├── MainPresenter.java
    │   ├── RutinaPresenter.java
    │   ├── EjercicioPresenter.java
    │   ├── CamaraPresenter.java
    │   └── HistorialPresenter.java
    │
    ├── ui/                         # Implementación concreta de la UI
    │   └── AppConsola.java         # Implementa todas las interfaces View
    │
    └── main/
        └── Main.java               # Punto de entrada
```

---

## 🏗️ Capas y responsabilidades

| Capa | Paquete | Responsabilidad |
|------|---------|-----------------|
| **Model** | `model` | Entidades de dominio puras (POJOs) |
| **DAO** | `dao` / `dao.impl` | Acceso y persistencia de datos en memoria |
| **Service** | `service` | Lógica de negocio (descripciones, cronómetro, historial) |
| **View** | `view` | Interfaces que definen el contrato UI ↔ Presenter |
| **Presenter** | `presenter` | Lógica de presentación; coordina Service/DAO → View |
| **UI** | `ui` | Solo muestra datos y captura input. Sin lógica de negocio |

---

## 🔄 Flujo MVP

```
Usuario
  │
  ▼
AppConsola (ui)          ← implementa IMainView, IRutinaView, ...
  │  captura input
  ▼
XxxPresenter (presenter) ← procesa la acción
  │  consulta datos
  ▼
XxxService (service)     ← lógica de negocio
  │  (o DAO directamente)
  ▼
Presenter actualiza View
  │
  ▼
AppConsola muestra resultado
```

---

## 🚀 Compilación y ejecución

### Con terminal (javac)

```bash
# Desde la raíz del proyecto
mkdir -p out
javac -d out -sourcepath src $(find src -name "*.java")
java -cp out main.Main
```

### Con IntelliJ IDEA

1. Abre el proyecto: `File > Open > carpeta HomeFit`
2. Marca `src` como Sources Root: clic derecho → `Mark Directory as > Sources Root`
3. Ejecuta `main/Main.java`

### Con Eclipse

1. `File > New > Java Project`
2. Desmarca "Use default location" y apunta a la carpeta `HomeFit`
3. Run As > Java Application → selecciona `main.Main`

---

## 🗺️ Pantallas y navegación

```
P1 (Inicio)
 ├─ 1/2/3 → P2 (Rutina)
 │            ├─ 1/2/3 → P3 (Ejercicio)
 │            │            ├─ 1 → Video (vuelve a P3)
 │            │            └─ 2 → P4 (Cámara)
 │            │                    ├─ 1 → P5 (Foto)
 │            │                    │       ├─ 1 → P4
 │            │                    │       └─ 2 → P1 + guarda historial
 │            │                    └─ 2 → P3
 │            └─ 4/5 → P1
 └─ 4 → P6 (Historial)
          └─ N → P7 (Detalle sesión)
                  └─ N → P8 (Foto ampliada)
                          └─ 1 → editar nota → P8
```

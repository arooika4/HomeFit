package presenter;

import service.CronometroService;
import view.ICamaraView;

public class CamaraPresenter {

    private final ICamaraView view;
    private final CronometroService cronometroService;

    private String tiempoFormateado = "00:00:00";

    public CamaraPresenter(ICamaraView view, CronometroService cronometroService) {
        this.view              = view;
        this.cronometroService = cronometroService;
    }
   
    public void mostrarCamara() {
        view.mostrarPantallaCamara();
    }

    public String procesarOpcionCamara(String opcion) {
        switch (opcion.trim()) {
            case "1":
                cronometroService.detener();
                tiempoFormateado = cronometroService.formatearTiempo();
                view.mostrarFotoRealizada(tiempoFormateado);
                return "FOTO";
            case "2": return "ATRAS";
            default:
                view.mostrarMensajeError("[Opción no reconocida]");
                return "INVALIDA";
        }
    }

    public String procesarOpcionFoto(String opcion) {
        switch (opcion.trim()) {
            case "1":
                cronometroService.iniciar();
                view.mostrarPantallaCamara();
                return "REPETIR";
            case "2":
                return "TERMINAR";
            default:
                view.mostrarMensajeError("[Opción no reconocida]");
                return "INVALIDA";
        }
    }

    public String getTiempoFormateado() { return tiempoFormateado; }
}

package presenter;

import service.EjercicioService;
import view.IEjercicioView;

public class EjercicioPresenter {

    private final IEjercicioView view;
    private final EjercicioService ejercicioService;

    private String nombreEjercicio;

    public EjercicioPresenter(IEjercicioView view, EjercicioService ejercicioService) {
        this.view             = view;
        this.ejercicioService = ejercicioService;
    }

    public void cargarEjercicio(String nombreEjercicio) {
        this.nombreEjercicio = nombreEjercicio;
        String descripcion = ejercicioService.obtenerDescripcion(nombreEjercicio);
        view.mostrarDetalleEjercicio(nombreEjercicio, descripcion);
    }

    public String procesarOpcion(String opcion) {
        switch (opcion.trim()) {
            case "1":
                view.mostrarVideoSimulado(nombreEjercicio);
                return "VIDEO";
            case "2": return "CAMARA";
            case "3": return "ATRAS";
            case "4": return "INICIO";
            default:
                view.mostrarMensajeError("[Opción no reconocida]");
                return "INVALIDA";
        }
    }

    public String getNombreEjercicio() { return nombreEjercicio; }
}

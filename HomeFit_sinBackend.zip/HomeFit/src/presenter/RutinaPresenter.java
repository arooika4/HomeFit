package presenter;

import service.EjercicioService;
import service.RutinaService;
import view.IRutinaView;

import java.util.List;

public class RutinaPresenter {

    private final IRutinaView view;
    private final RutinaService rutinaService;
    private final EjercicioService ejercicioService;

    private int indiceRutina;
    private String nombreRutina;
    private List<String> ejercicios;

    public RutinaPresenter(IRutinaView view,
                           RutinaService rutinaService,
                           EjercicioService ejercicioService) {
        this.view             = view;
        this.rutinaService    = rutinaService;
        this.ejercicioService = ejercicioService;
    }

    public void cargarRutina(int indiceRutina) {
        this.indiceRutina = indiceRutina;
        this.nombreRutina = rutinaService.obtenerNombreRutina(indiceRutina);
        this.ejercicios   = ejercicioService.obtenerEjerciciosPorRutina(indiceRutina);
        view.mostrarEjercicios(nombreRutina, ejercicios);
    }

    public String procesarOpcion(String opcion) {
        switch (opcion.trim()) {
            case "1": return ejercicios.get(0);
            case "2": return ejercicios.get(1);
            case "3": return ejercicios.get(2);
            case "4": return "ATRAS";
            case "5": return "INICIO";
            default:
                view.mostrarMensajeError("[Opción no reconocida]");
                return "INVALIDA";
        }
    }

    public String getNombreRutina() { return nombreRutina; }
    public int getIndiceRutina()    { return indiceRutina; }
}

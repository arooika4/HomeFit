package service;

public class CronometroService {

    private long tiempoInicioMs = 0;
    private long tiempoTranscurridoMs = 0;

    public void iniciar() {
        tiempoInicioMs = System.currentTimeMillis();
    }

    public void detener() {
        tiempoTranscurridoMs = System.currentTimeMillis() - tiempoInicioMs;
    }

    public long getTiempoTranscurridoMs() {
        return tiempoTranscurridoMs;
    }

    public String formatearTiempo() {
        return formatearTiempo(tiempoTranscurridoMs);
    }

    public static String formatearTiempo(long ms) {
        long totalSeg = ms / 1000;
        long horas    = totalSeg / 3600;
        long minutos  = (totalSeg % 3600) / 60;
        long segundos = totalSeg % 60;
        return String.format("%02d:%02d:%02d", horas, minutos, segundos);
    }
}

package service;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class EjercicioService {

    private static final String[][] EJERCICIOS_POR_RUTINA = {
        {"Push up tradicional", "Vuelo lateral", "Fondos de tríceps"},
        {"Sentadilla con peso corporal", "Estocada búlgara", "Puente de glúteo"},
        {"Bicicleta abdominal", "Crunch abdominal", "Plancha"}
    };

    private static final Map<String, String> DESCRIPCIONES = new HashMap<>();

    static {
        DESCRIPCIONES.put("Push up tradicional",
            "  CONSEJOS:\n" +
            "  • Intenta que tus codos queden ligeramente por debajo de la línea de tus hombros.\n" +
            "  • Baja en un solo bloque, manteniendo el abdomen contraído y evitando\n" +
            "    que tu columna se deforme.\n\n" +
            "  Las flexiones son un ejercicio multiarticular que involucra principalmente\n" +
            "  pecho, hombros y tríceps, al tiempo que requiere activación constante del\n" +
            "  core para mantener la alineación corporal. Según el American Council on\n" +
            "  Exercise, también generan una importante activación abdominal y estabilizadora,\n" +
            "  mejorando la estabilidad corporal y el control postural.\n\n" +
            "  Dificultad (3 series):\n" +
            "  • Novato: 8 repeticiones\n" +
            "  • Intermedio: 15 repeticiones\n" +
            "  • Avanzado: 25+ repeticiones");

        DESCRIPCIONES.put("Vuelo lateral",
            "  CONSEJOS:\n" +
            "  • Puedes usar cualquier objeto con peso: botellas, paquetes de arroz, etc.\n" +
            "  • Mantén los hombros hacia abajo y los codos ligeramente extendidos.\n\n" +
            "  El vuelo lateral fortalece el deltoides medio, responsable de la elevación\n" +
            "  lateral del brazo. Contribuye a la fuerza y resistencia del hombro,\n" +
            "  mejora la estabilidad escapular y previene desequilibrios musculares\n" +
            "  en la cintura escapular.\n\n" +
            "  Dificultad (3 series):\n" +
            "  • Novato: 10 repeticiones\n" +
            "  • Intermedio: 15 repeticiones\n" +
            "  • Avanzado: 20+ repeticiones");

        DESCRIPCIONES.put("Fondos de tríceps",
            "  CONSEJOS:\n" +
            "  • Concéntrate en que el movimiento provenga desde los codos.\n" +
            "  • Junta tus escápulas durante el ejercicio y mantén la postura.\n" +
            "  • Con las piernas flexionadas el movimiento es más sencillo.\n\n" +
            "  Los fondos de tríceps fortalecen el tríceps braquial, principal músculo\n" +
            "  responsable de la extensión del codo. También participan músculos\n" +
            "  estabilizadores del hombro y del tronco, mejorando la fuerza del\n" +
            "  miembro superior y el control corporal en movimientos de empuje.\n\n" +
            "  Dificultad (3 series):\n" +
            "  • Novato: 8 repeticiones\n" +
            "  • Intermedio: 15 repeticiones\n" +
            "  • Avanzado: 20+ repeticiones");

        DESCRIPCIONES.put("Sentadilla con peso corporal",
            "  CONSEJOS:\n" +
            "  • Si te resulta difícil alcanzar profundidad, puedes realizarla hacia un cajón.\n" +
            "  • Desciende de forma controlada, evitando que tus rodillas se junten.\n" +
            "  • Intenta mantener alineadas tus rodillas con la punta de tus pies.\n\n" +
            "  La sentadilla activa simultáneamente cuádriceps, glúteos e isquiotibiales,\n" +
            "  reproduciendo un patrón funcional presente en la vida diaria. Según\n" +
            "  Scientific Reports, mejora la fuerza, la capacidad funcional y la\n" +
            "  composición corporal incluso solo con el peso corporal.\n\n" +
            "  Dificultad (3 series):\n" +
            "  • Novato: 10 repeticiones\n" +
            "  • Intermedio: 20 repeticiones\n" +
            "  • Avanzado: 30+ repeticiones");

        DESCRIPCIONES.put("Estocada búlgara",
            "  CONSEJOS:\n" +
            "  • Pie delantero más adelantado: más dominante de cadera.\n" +
            "  • Pie delantero más atrás: más dominante de rodilla.\n" +
            "  • Alcanza la mayor profundidad posible manteniendo el tronco estable.\n" +
            "  • Al bajar, procura que tu rodilla no sobrepase excesivamente la punta del pie.\n\n" +
            "  Ejercicio unilateral que trabaja intensamente cuádriceps y glúteos,\n" +
            "  exigiendo alto control del equilibrio. Ha demostrado ser especialmente\n" +
            "  eficaz para mejorar la estabilidad de cadera y rodilla, corregir\n" +
            "  asimetrías de fuerza y desarrollar fuerza funcional.\n\n" +
            "  Dificultad (3 series):\n" +
            "  • Novato: 8 repeticiones por pierna\n" +
            "  • Intermedio: 12 repeticiones por pierna\n" +
            "  • Avanzado: 16+ repeticiones por pierna");

        DESCRIPCIONES.put("Puente de glúteo",
            "  CONSEJOS:\n" +
            "  • Pies adelantados: mayor tensión en isquiotibiales.\n" +
            "  • Pies cerca del cuerpo: mayor tensión en glúteos.\n" +
            "  • Empuja con los talones y contrae fuertemente los glúteos al extender la cadera.\n\n" +
            "  Fortalece el glúteo mayor y los isquiotibiales, centrándose en la\n" +
            "  extensión de cadera. Estudios de activación muscular demuestran altos\n" +
            "  niveles de activación del glúteo mayor, mejorando la estabilidad lumbar,\n" +
            "  la postura y reduciendo el riesgo de sobrecarga en la zona lumbar.\n\n" +
            "  Dificultad (3 series):\n" +
            "  • Novato: 12 repeticiones\n" +
            "  • Intermedio: 20 repeticiones\n" +
            "  • Avanzado: 30+ repeticiones");

        DESCRIPCIONES.put("Bicicleta abdominal",
            "  CONSEJOS:\n" +
            "  • Mantén la zona lumbar pegada al suelo durante todo el movimiento.\n" +
            "  • Alterna llevando el codo hacia la rodilla contraria mientras extiendes la otra.\n" +
            "  • Realiza el movimiento de forma controlada, sin tirar del cuello con las manos.\n\n" +
            "  Combina flexión de tronco con rotación, activando recto abdominal\n" +
            "  y oblicuos. Investigaciones muestran altos niveles de actividad\n" +
            "  en la musculatura abdominal, especialmente oblicuos, gracias al\n" +
            "  componente rotacional, desarrollando la fuerza y estabilidad del core.\n\n" +
            "  Dificultad (3 series):\n" +
            "  • Novato: 20 repeticiones\n" +
            "  • Intermedio: 40 repeticiones\n" +
            "  • Avanzado: 60+ repeticiones");

        DESCRIPCIONES.put("Crunch abdominal",
            "  CONSEJOS:\n" +
            "  • Eleva ligeramente los hombros del suelo contrayendo el abdomen.\n" +
            "  • Mantén la zona lumbar apoyada y evita impulsarte con el cuello.\n" +
            "  • Realiza repeticiones rápidas pero controladas, manteniendo tensión en el abdomen.\n\n" +
            "  Ejercicio clásico para fortalecer el recto abdominal, responsable de\n" +
            "  la flexión del tronco. Según el American Council on Exercise, genera\n" +
            "  una activación significativa del recto abdominal, siendo eficaz para\n" +
            "  desarrollar fuerza y resistencia del core.\n\n" +
            "  Dificultad (3 series):\n" +
            "  • Novato: 15 repeticiones\n" +
            "  • Intermedio: 30 repeticiones\n" +
            "  • Avanzado: 50+ repeticiones");

        DESCRIPCIONES.put("Plancha",
            "  CONSEJOS:\n" +
            "  • Coloca los antebrazos debajo de los hombros y mantén el cuerpo en línea recta.\n" +
            "  • Activa el abdomen y los glúteos para evitar que la cadera se hunda.\n" +
            "  • Mantén el cuello alineado con la columna mirando hacia el suelo.\n\n" +
            "  Activa simultáneamente transverso abdominal, oblicuos y musculatura\n" +
            "  lumbar mediante contracción isométrica. Investigaciones demuestran que\n" +
            "  mejora la resistencia del core, el control postural y la estabilidad\n" +
            "  de la columna, reduciendo el riesgo de molestias lumbares.\n\n" +
            "  Dificultad (3 series):\n" +
            "  • Novato: 20 segundos\n" +
            "  • Intermedio: 1 minuto\n" +
            "  • Avanzado: 2+ minutos");
    }

    public List<String> obtenerEjerciciosPorRutina(int indiceRutina) {
        return Arrays.asList(EJERCICIOS_POR_RUTINA[indiceRutina]);
    }

    public String obtenerDescripcion(String nombreEjercicio) {
        return DESCRIPCIONES.getOrDefault(nombreEjercicio, "  (Descripción no disponible)");
    }

    public String obtenerVideoReferencia(String nombreEjercicio) {
        return "https://homefit.app/videos/" + nombreEjercicio.toLowerCase().replace(" ", "-");
    }
}

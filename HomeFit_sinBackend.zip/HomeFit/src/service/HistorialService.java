package service;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class HistorialService {

    public static class RegistroSesion {
        public final String ejercicio;
        public final String tiempo;
        public final String fecha;
        public String notas;

        public RegistroSesion(String ejercicio, String tiempo, String fecha) {
            this.ejercicio = ejercicio;
            this.tiempo    = tiempo;
            this.fecha     = fecha;
            this.notas     = "";
        }
    }

    private final List<RegistroSesion> historial = new ArrayList<>();

    public void agregarRegistro(String ejercicio, String tiempo, String fecha) {
        historial.add(new RegistroSesion(ejercicio, tiempo, fecha));
    }

    public Map<String, List<RegistroSesion>> obtenerPorFecha() {
        Map<String, List<RegistroSesion>> mapa = new LinkedHashMap<>();
        for (RegistroSesion r : historial) {
            mapa.computeIfAbsent(r.fecha, k -> new ArrayList<>()).add(r);
        }
        return mapa;
    }

    public List<String> obtenerFechas() {
        return new ArrayList<>(obtenerPorFecha().keySet());
    }

    public boolean estaVacio() {
        return historial.isEmpty();
    }
}

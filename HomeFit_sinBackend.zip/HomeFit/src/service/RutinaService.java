package service;

import java.util.Arrays;
import java.util.List;

public class RutinaService {

    private static final String[] NOMBRES_RUTINAS = {
        "Tren superior",
        "Tren inferior",
        "Core"
    };

    public List<String> obtenerNombresRutinas() {
        return Arrays.asList(NOMBRES_RUTINAS);
    }

    public String obtenerNombreRutina(int indice) {
        if (indice < 0 || indice >= NOMBRES_RUTINAS.length) {
            throw new IllegalArgumentException("Índice de rutina no válido: " + indice);
        }
        return NOMBRES_RUTINAS[indice];
    }

    public int totalRutinas() {
        return NOMBRES_RUTINAS.length;
    }
}

package view;

public interface ICamaraView {
    void mostrarPantallaCamara();
    void mostrarFotoRealizada(String tiempoFormateado);
    void mostrarMensajeError(String mensaje);
}

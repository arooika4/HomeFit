package view;

public interface IEjercicioView {
    void mostrarDetalleEjercicio(String nombreEjercicio, String descripcion);
    void mostrarVideoSimulado(String nombreEjercicio);
    void mostrarMensajeError(String mensaje);
}

package view;

public interface IMainView {
    void mostrarMenuPrincipal();
    void mostrarMensajeError(String mensaje);
}

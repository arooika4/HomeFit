package view;

import java.util.List;

public interface IRutinaView {
    void mostrarEjercicios(String nombreRutina, List<String> ejercicios);
    void mostrarMensajeError(String mensaje);
}
